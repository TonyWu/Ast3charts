<!--

waJSQuery.fn.outerScrollHeight=function(includeMargin){
var element=this[0];
var jElement=waJSQuery(element);
var totalHeight=element.scrollHeight;


totalHeight+=jElement.outerHeight(includeMargin)-jElement.innerHeight();
return totalHeight;
};
waJSQuery(window).load(function(){
initializeAllWA_dialog();
});
waJSQuery(window).resize(function()
{
WA_Dialog.resizeUI()
});
waJSQuery(window).scroll(function()
{
});
waJSQuery(window).keypress(function(e){
if(WA_Dialog.xpneo)
{
var geEVA=WA_Dialog.xpneo
geEVA.onCustomKeypress(e.which)
}
});
waJSQuery(window).keydown(function(e){
if(WA_Dialog.xpneo)
{
var geEVA=WA_Dialog.xpneo
geEVA.onkeydown(e.which)
}
});
function vqNta()
{
var RLFwp=WA_GetCookie("wa-js-password");
var nNiIv=waJSQuery("#is-password-form-layer")
if(nNiIv.length>0)
{
var GgoaN=nNiIv.find("FORM")
var NkNvo=GgoaN.find(".waInputPassword")
if(MD5("#"+RLFwp+"#")==extractParamInfo(NkNvo,"crc"))
{
return false;
}
}
return true;
}
function SfKnf()
{
var nNiIv=waJSQuery("#is-password-form-layer") 
if(vqNta()==false)
{
nNiIv.hide()
waJSQuery("#is-global-layer").show()
initializeWA_JQuery()
return true
}
else
{
var GgoaN=nNiIv.find("FORM")
var NkNvo=GgoaN.find(".waInputPassword")
NkNvo.focus()
}
return false
}
function initializeAllWA_dialog()
{
if(document.wa_page_under_construction)
{
var w=new WA_Dialog(false);
w.MFItT(Translator.tr("Page Under construction")+"<br><a href='index.html'>index.html</a>")
}
if(SfKnf()==false)
{
var nNiIv=waJSQuery("#is-password-form-layer")
if(nNiIv.length>0)
{
nNiIv.show()
var GgoaN=nNiIv.find("FORM")
GgoaN.submit(function()
{
var NkNvo=GgoaN.find(".waInputPassword")
RLFwp=NkNvo.val();
WA_SetCookie("wa-js-password",RLFwp);
SfKnf()
return false;
})
}
}
}
function createWaButton(FZbhn)
{
var HgLQK={
x:0,y:0,position:"absolute",w:50,h:25,corner:4,shadow:false,label:"Texte",
fct:function(){alert('call function')},fct_obj:null,id:""}
if(FZbhn==undefined) FZbhn=new Array();
for(k in HgLQK)
{
if(FZbhn[k]==undefined) FZbhn[k]=HgLQK[k]
}
var skiHD=FZbhn.label.replace(" ","&nbsp;")
var OjEXY=""
var rmVXg=CONST_WA_GLOBAL_SETTINGS.theme.buttons
var HEKRJ=compliantColor(rmVXg.bg)
var AQrXa=compliantColor(rmVXg.bg)
var fbYSS=compliantColor(rmVXg.text)
var sWLpR=compliantColor(rmVXg.border)
var ciHKl=compliantColor(rmVXg.bg_over)
var AQrXa_over=compliantColor(rmVXg.bg_over)
var NZexd=compliantColor(rmVXg.text_over)
var sWLpR_over=compliantColor(rmVXg.border_over)
var HEWfR="param[bord("+sWLpR_over+") inner_bord() bg("+ciHKl+" "+AQrXa_over+") txt("+NZexd+") bg_img() img() ]"
var CqOYf="param[grad(0 0 0 "+FZbhn.h+" "+HEKRJ+" "+AQrXa+") bord("+sWLpR+") inborder() ]" 
OjEXY+="<div id='"+FZbhn.id+"' class=\"wa-button-link wa-js-action "+HEWfR+"\" style='position:"+FZbhn.position+";z-index:1000012;width:"+FZbhn.w+"px;height:"+FZbhn.h+"px;left:"+FZbhn.x+"px;top:"+FZbhn.y+"px;'>";
OjEXY+="<button class=\"wa-button "+CqOYf+"\" style=\"position:static;top:0px;left:0px;background-color:red;margin:0px;padding:0px;spacing:0px;width:"+(FZbhn.w)+"px;height:"+(FZbhn.h)+"px;-moz-border-radius:"+FZbhn.corner+"px;border-radius:"+FZbhn.corner+"px "+FZbhn.corner+"px "+FZbhn.corner+"px "+FZbhn.corner+"px;";
if(FZbhn.shadow) OjEXY+="-webkit-box-shadow: 1px 1px 12px #555;-moz-box-shadow: 1px 1px 12px #555;box-shadow: 1px 1px 12px #555;"
OjEXY+="border:1px solid "+sWLpR+";";
OjEXY+="background:-webkit-gradient(linear,0 0, 0 "+FZbhn.h+",from("+HEKRJ+"),to("+AQrXa+"));background:-moz-linear-gradient(top left 270deg,"+HEKRJ+" 0px,"+AQrXa+" "+FZbhn.h+"px);text-align:center;color:"+fbYSS+";\" >"
OjEXY+="<div>";
OjEXY+="<a href='javascript:void(0)' class='wa-but-txt' style=\"position:relative;cursor:pointer;margin:0px;padding:0px;display:inline;vertical-align:middle;font-weight:normal;font-size:12px;color:"+fbYSS+";font-family:Arial;text-decoration:none;\">"+skiHD+"</a>"
OjEXY+="</div>";
OjEXY+="</button>"
OjEXY+="</div>" 

return OjEXY
}
function activateWaButton(FZbhn)
{
var lCKPx=waJSQuery("#"+FZbhn.id)
if(lCKPx.length==0)
{
}
else
{
lCKPx.click(function(){FZbhn.fct.call(FZbhn.fct_obj,FZbhn.fct_params)})
lCKPx.css("cursor","pointer")
}
}
function WA_Dialog(GIgNM_close_button)
{
this.aLMTO=0;
this.QINwj=0;
this.SHirq_win_width=600;
this.dRUdF=400;
this.sVnUj=200;
this.AetoB=new Array();
this.aGPto="wa-dialog-but-";
this.Rgeok=this.aGPto+"div-";
this.BUTTON_HEIGHT=22;
this.GIgNM_close_button=GIgNM_close_button;
this.KKPww=""
this.qqfBb=16;
this.size=function()
{
return new Size(this.aLMTO,this.QINwj)
}
this.setTitle=function(CXFZX)
{
this.KKPww=CXFZX
}
this.marginContent=function()
{
return this.qqfBb;
}
this.AlSWu=function()
{
if(this.GIgNM_close_button==undefined)this.GIgNM_close_button=true;
this.GtEKa();
}
this.resetButtons=function()
{
this.GtEKa();
}
this.idealHeight=function()
{
return this.Fqbrf
}
this.displayWindowWithAutoResize=function(tJYfT,oMrox)
{
this.Freqo=false
this.Fqbrf=tJYfT
this.vGAbI=oMrox 
this.resetButtons();
oMrox.call(this)
var l=document.getElementById('wa-dialog-content');
if(this.Freqo==false)
if(l.scrollHeight>200)
{
this.Freqo=true
this.Fqbrf=l.scrollHeight+150
this.resetButtons();
oMrox.call(this)
}
waHackButtons()
waActivateOverButtons()
waGlobalPatchIE()
}
this.initializeWindow=function(SHirq_lx,SHirq_ly)
{
if(WA_Dialog.xpneo)WA_Dialog.xpneo.closeWin()
WA_Dialog.xpneo=this;
this.SHirq_win_width=SHirq_lx;
this.dRUdF=SHirq_ly;
this.sVnUj=SHirq_ly
this.XatBv()
}
this.progress=function()
{
this.initializeWindow(300,130)
this.writeContent("<div align=center style=''>"+htmlDynamicLoader(true)+"</div>")
waActivateDynamicLoader(waJSQuery("#wa-dialog-content"),true)
}
this.MFItT=function(mess)
{
this.initializeWindow(450,130)
var s=""
s+="<table border=0 style='width:100%;'><tr>";
s+="<td align=center>"
s+=mess
s+="</td></tr></table>"
this.writeContent(s)
}
this.addButton=function(skiHD,GEVSL,qtwfu,DcOjp)
{
var wSBmM=this.AetoB.length
var LQrYb=Math.max((skiHD.length*8)*1.2+30,80)
var rRbrh=new Size(LQrYb,this.BUTTON_HEIGHT);
this.QKNsO("action_"+wSBmM,wSBmM,skiHD,GEVSL,rRbrh,qtwfu,DcOjp)
}
this.GtEKa=function()
{
this.AetoB=new Array();
}
this.QKNsO=function(dTZKc,wSBmM,skiHD,GEVSL,rRbrh,qtwfu,DcOjp)
{
var xPaNJ=[dTZKc,rRbrh,wSBmM,skiHD,GEVSL,qtwfu,DcOjp];
this.AetoB.push(xPaNJ);
}
this.writeContent=function(s)
{
waJSQuery("#wa-dialog-content").html(s)
this.adjustHeight() 

}
this.adjustHeight=function()
{
var fWgAT=waJSQuery("#wa-dialog-content").outerScrollHeight()+120;

fWgAT=Math.max(fWgAT,150)
this.dRUdF=fWgAT;
this.XFtwx()
}
this.scRAU=function(dTZKc)
{
for(var ivUmM=0;ivUmM<this.AetoB.length;ivUmM++)
{
var xPaNJ=this.AetoB[ivUmM];
if((xPaNJ[0]==dTZKc)||(xPaNJ[2]+""==dTZKc+""))
return xPaNJ;
}
return undefined;
}
this.qRpDt=function(dTZKc)
{
var xPaNJ=this.scRAU(dTZKc);
return xPaNJ[1]
}
this.IWlnk=function(wVahw)
{
var xPaNJ=this.scRAU(wVahw);
var rRbrh=this.qRpDt(wVahw)
var FZbhn={
id:this.Rgeok+xPaNJ[0],fct:xPaNJ[4],
fct_obj:xPaNJ[5],fct_params:xPaNJ[6],label:xPaNJ[3],w:rRbrh.width(),h:rRbrh.height()
}

return FZbhn;
}
this.PephL=function(wVahw)
{
return createWaButton(this.IWlnk(wVahw));
}
this.UlaCN=function(wVahw)
{
return activateWaButton(this.IWlnk(wVahw));
}
this.fghSd=function(dTZKc)
{
var xPaNJ=this.scRAU(dTZKc)
if(xPaNJ)
{
var hMuVT=this.Rgeok+xPaNJ[0];
return waJSQuery("#"+hMuVT)
}
return undefined
}
this.XatBv=function()
{
var l=waJSQuery('#wa-dialog-container');
l.show() 
var s="";
s+="<div class='wa-dialog-container-bg' style='position:absolute;left:0px;top:0px;' ></div>"
var xDnlH=document.webaca_banner_height
s+="<div id='wa-dialog-main' style='position:absolute;left:0px;top:"+xDnlH+"px;' >"
s+="<div style='position:absolute;left:0px;top:0px;width:100px;height:100px;' ></div>"
for(var cnipN in this.AetoB)
{
s+=this.PephL(this.AetoB[cnipN][2]);
}
if(this.GIgNM_close_button)
{
s+="<div id='wa-dialog-bt-close' class='wa-bt-close-style'>X</div>"
}
s+="<div id='wa-dialog-title' style='position:absolute;left:0px;top:0px;" 
s+=";' ></div>"
s+="<div id='wa-dialog-content' style='position:absolute;left:0px;top:0px;" 
if(isMSIE_lower_than_ie9()==false)
{
s+="overflow:auto;"
}
s+="' ></div>"
s+="</div>"
l.html(s);
for(var cnipN in this.AetoB)
{
this.UlaCN(this.AetoB[cnipN][2]);
}
var iDrQX=this;
WA_exec_callback_opera_compliant(this,this.IKHlL)
var pHUkE=l.find(".wa-dialog-container-bg")
pHUkE.click(function(){
iDrQX.closeWin()
});
waSetVisibilityMainPageContenair(false)
}
this.IKHlL=function()
{
this.okOMs=waJSQuery(window).scrollTop() 
this.XFtwx()
var iDrQX=this;
var oBBxh=waJSQuery("#wa-dialog-bt-close")
oBBxh.html("<a id='wa-dialog-bt-close-inner' style='position: absolute; text-align: center; left: 24px; top: -16px; background: url(&quot;wa_closecross.png&quot;) no-repeat;width: 35px;height:35px;'></a>");
oBBxh.click(function(){
iDrQX.closeWin()
return false;
}) 


waHackButtons()
waActivateOverButtons()
}
this.intern_closeWin=function()
{
waJSQuery("#wa-dialog-container").hide()
waJSQuery("#wa-dialog-container").empty()
WA_Dialog.xpneo=false
waSetVisibilityMainPageContenair(true)
}
this.closeWin=function()
{
if(this.GIgNM_close_button!=true) return
this.intern_closeWin()
}
this.onCustomKeypress=function(NPAUN)
{
if((this.AetoB.length==1)&&(NPAUN==13))
{
this.closeWin()
return true;
}
return false;
}
this.onkeypress=function(NPAUN)
{
return this.onCustomKeypress(NPAUN)
}
this.onkeydown=function(NPAUN)
{
if(NPAUN==27)
{
if(this.GIgNM_close_button)
{
this.closeWin()
return true;
}
}
return this.onCustomKeypress(NPAUN) 
}
this.customUpdate=function(){}
this.XFtwx=function()
{
var CXFZX=waJSQuery("#wa-dialog-title")
CXFZX.html("<div id='wa-dialog-title-inner' style='position:absolute;'>"+this.KKPww+"</div>")
var ZhwWJ=document.webaca_width_page;
var bBPXG=document.webaca_height_page;
var fQqTB=getDocumentSize().width()
var qIwlm=getDocumentSize().height()
var LjTrv=getWindowSize().width()
var HfbwH=getWindowSize().height() 

var dbgYZ=550;
var oagSD=400;
fQqTB=Math.max(fQqTB,dbgYZ);
qIwlm=Math.max(qIwlm,oagSD);
this.aLMTO=Math.min(fQqTB*0.9,this.SHirq_win_width) 
this.QINwj=Math.max(this.sVnUj,this.dRUdF)
var QJeup=waJSQuery(window).scrollTop()+(fQqTB-this.aLMTO)/2 
var SITJT=waJSQuery(window).scrollLeft()+(qIwlm-this.QINwj)/2
QJeup=(fQqTB-this.aLMTO)/2
SITJT=(qIwlm-this.QINwj)/2
QJeup=Math.max(0,QJeup)
SITJT=Math.max(0,SITJT) 
var uxJDr=waJSQuery('#wa-dialog-main')
uxJDr.css({left:QJeup,top:SITJT,width:this.aLMTO,height:this.QINwj})
var qqfBb=this.qqfBb;

var SJUuF=this.AetoB.length;
var MLVmY=10;
var tpQNx=0;
for(var cnipN=0;cnipN<SJUuF;cnipN++)
{
if(cnipN>0) tpQNx+=MLVmY;
var rRbrh_but=this.qRpDt(cnipN);
tpQNx+=rRbrh_but.width();
}
var WdmPH=(this.aLMTO-tpQNx)/2
for(var cnipN=0;cnipN<SJUuF;cnipN++)
{
if(cnipN>0) WdmPH+=MLVmY;
var lCKPx_div=this.fghSd(cnipN);
var rRbrh_but=this.qRpDt(cnipN);
lCKPx_div.css({left:WdmPH,top:this.QINwj-rRbrh_but.height()-2*qqfBb})
WdmPH+=rRbrh_but.width();
}
var krmab=47;
var WNXJp=this.BUTTON_HEIGHT+2*qqfBb;
if(SJUuF==0)
{
WNXJp=0;
}
var uGuUo=(this.QINwj-krmab-WNXJp)-qqfBb
var CucnM=waJSQuery("#wa-dialog-content")
var ZHOUa_content=Math.round(this.aLMTO-2*qqfBb)
var wWhgF=Math.round(uGuUo)
this.m_content_lx=ZHOUa_content
this.m_content_ly=wWhgF
CucnM.css({left:Math.round((this.aLMTO-ZHOUa_content)/2),top:Math.round(krmab+(uGuUo-wWhgF)/2),width:ZHOUa_content,height:wWhgF}) 
CXFZX.css({left:qqfBb,top:0,width:ZHOUa_content,height:krmab})
var JFpdJ=waJSQuery("#wa-dialog-title-inner")
var kdCqA=(CXFZX.height()-JFpdJ.height())/2;
JFpdJ.css("top",kdCqA) 
var iDrQX=this;
var oBBxh=waJSQuery("#wa-dialog-bt-close") 
var TCBXe=waJSQuery("#wa-dialog-bt-close-inner") 
oBBxh.css({top:0,left:this.aLMTO-oBBxh.width(),cursor:"pointer"})
this.customUpdate() 

var kDgbq=waJSQuery("#wa-dialog-container") 
centerFullPageContainer();
}
this.AlSWu();
}

WA_Dialog.getCurrent=function()
{
return WA_Dialog.xpneo;
}
WA_Dialog.xpneo=false;
WA_Dialog.resizeUI=function()
{
if(WA_Dialog.xpneo)
{
var geEVA=WA_Dialog.xpneo
if(isAppleMobile()==false)
{
geEVA.XFtwx()
}
}
}
WA_Dialog.alert=function(s)
{
var w=new WA_Dialog();
w.setTitle(Translator.tr("Information"))
w.MFItT(s)
}
WA_Dialog.progress=function()
{
var w=new WA_Dialog(false);
w.progress()
}
function centerFullPageContainer()
{
var ZhwWJ=document.webaca_width_page;
var bBPXG=document.webaca_height_page;
var kDgbq=waJSQuery('#wa-dialog-container');
var LjTrv=waJSQuery(window).width()
var HfbwH=waJSQuery(window).height()
var SITJT_bg=waJSQuery(window).scrollTop();
var geEVA=WA_Dialog.getCurrent()
var qovPt=geEVA&&isAppleMobile();
if(qovPt)
{
}
var EXdDa=0;
var BAPxd=waJSQuery("#wa-dialog-main") 
if((BAPxd.length>0)&&(geEVA!=false))
{
var SeGQF=0;
var dJLte=0;
if(BAPxd.width()<=waJSQuery(window).width())
{
SeGQF=(waJSQuery(window).width()-BAPxd.width())/2+waJSQuery(window).scrollLeft()
}
else
{
var xDialogCenter=(ZhwWJ-BAPxd.width())/2
SeGQF=xDialogCenter
var x0=xDialogCenter+BAPxd.width()/2-waJSQuery(window).width()
if(waJSQuery(window).scrollLeft()>x0+BAPxd.width()/2)
{
var oQJmD=waJSQuery(window).scrollLeft()-x0
SeGQF+=oQJmD-BAPxd.width()/2
}
if(waJSQuery(window).scrollLeft()<xDialogCenter)
{
var oQJmD=xDialogCenter-waJSQuery(window).scrollLeft()
SeGQF-=oQJmD
}
}
if(BAPxd.height()<=waJSQuery(window).height())
{
dJLte=(waJSQuery(window).height()-BAPxd.height())/2+waJSQuery(window).scrollTop()
}
else
{
var yDialogCenter=(bBPXG-BAPxd.height())/2
dJLte=yDialogCenter
var y0=yDialogCenter+BAPxd.height()/2-waJSQuery(window).height()
if(waJSQuery(window).scrollTop()>y0+BAPxd.height()/2)
{
var oQJmD=waJSQuery(window).scrollTop()-y0
dJLte+=oQJmD-BAPxd.height()/2
}
if(waJSQuery(window).scrollTop()<yDialogCenter)
{
var oQJmD=yDialogCenter-waJSQuery(window).scrollTop()
dJLte-=oQJmD
}
dJLte=geEVA.okOMs
dJLte=Math.min(dJLte,waJSQuery(window).scrollTop())
var hUNci=(waJSQuery(window).scrollTop()+waJSQuery(window).height())-BAPxd.height()
dJLte=Math.max(dJLte,hUNci)
dJLte+=10
}



{
BAPxd.css({left:SeGQF,top:dJLte})
}
}
var CLMJe=waJSQuery(window).width();
var KoAqC=waJSQuery(window).height();
if(CLMJe<ZhwWJ)
{
CLMJe=waJSQuery(document).width();
}
if(KoAqC<bBPXG)
{
KoAqC=waJSQuery(document).height();
}
if((BAPxd.length>0)&&(geEVA!=false))
{
kDgbq.css({left:0,top:0,width:CLMJe,height:KoAqC})
var pHUkE=kDgbq.find(".wa-dialog-container-bg");

pHUkE.css({left:0,top:0,width:CLMJe,height:KoAqC}) 
var msGCF=new RGBColor(CONST_WA_GLOBAL_SETTINGS.overlayColor)
pHUkE.css({"backgroundColor":msGCF.toHexaOpaqueColor(),"opacity":msGCF.a})
kDgbq.show()
}
}

-->
