<?php
require_once( 'wa-admin/wa_dyn_blog.php' );
?>