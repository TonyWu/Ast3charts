waJSQuery(window).load(function(){
initializeAllWA_gallery();
});
function nMnqd()
{
var kDgbq=waJSQuery(".wa-fullscreen-contenair:visible");
var GQvAH=kDgbq.find(".wa-gallery")
if(GQvAH.length>0)
{
var DYqne=kDgbq.data("wa-window-size")
if((DYqne==undefined)||((DYqne.width()!=getWindowSize().width())||(DYqne.height()!=getWindowSize().height())))
{
var kgClC=HKWMJ(GQvAH)
var lwRpn=kgClC.data("timer_resize")
if(lwRpn!=null)
{
clearTimeout(lwRpn)
kgClC.data("timer_resize",null)
}
lwRpn=wa_timeout(function(){afCNQ(GQvAH)},200);
kgClC.data("timer_resize",lwRpn)
kDgbq.data("wa-window-size",getWindowSize())
}
}
}
waJSQuery(window).scroll(function()
{
nMnqd()
});
waJSQuery(window).resize(function()
{
nMnqd()
});
function centerGalleryContainer()
{
return;
var kDgbq=waJSQuery('#wa-dialog-container');
var EXdDa=waJSQuery(window).scrollLeft();
var oBxTl=waJSQuery(window).scrollTop();
var Clptv=getWindowSize()
var GQvAH=kDgbq.find(".wa-gallery")
if(GQvAH.length>0)
{
kDgbq.css({left:EXdDa,top:oBxTl,width:Clptv.width(),height:Clptv.height()})
kDgbq.show()
}
}
function KBTRN(kpvpM,rAtgC)
{
if(rAtgC<0)rAtgC=0;
var uBNjl=CsICf(kpvpM);
if(!kpvpM.data("datas"))
{
alert('browser error')
return;
}
var SQRHb=YCewR(kpvpM)
var JVFCU=wAqli(kpvpM);
if(JVFCU<=0) return;
if(rAtgC+1>Math.ceil(SQRHb/JVFCU)) return;
if(uBNjl==rAtgC) return;
var UPtqY=kpvpM.find(".wa-gallery-page-selector") 
var GGFvl=CXUII(kpvpM)
var SSLnk=(GGFvl==0)?1:0;
var SVXYD=nXMHd(kpvpM,GGFvl);
var XcMJN=nXMHd(kpvpM,SSLnk);
var WIACt=kpvpM.find(".wa-gallery-scroll-pane");
var ganPu=500;
if(LHqbJ(kpvpM))return;
MKJqh(kpvpM,true)
var OQdgk=kpvpM.data("mode")
var RxmUM=kpvpM.data("type_gallery") 
var hPnnx=kpvpM.data("datas").global_config.transition_effect/100;
if(OQdgk!="fullscreen")
{
if(RxmUM==0)
{
hPnnx=1;
}
}
var vlJlu=hPnnx;
var hhmwB=true;
if(hPnnx>0.85)
{
hhmwB=false 
}
if(isMobileBrowser()&&(isIPad()==false))
{
if(hPnnx<0.5)
{
vlJlu=0
}
else
{
hhmwB=false
vlJlu=1
}
}
if(hhmwB)
{
XcMJN.fadeIn(ganPu)
SVXYD.fadeOut(ganPu)
}
else
{
XcMJN.show() 
}
var VmkZm=0;
var kOJru=WIACt.position().left
if(rAtgC>uBNjl)
{
VmkZm=SVXYD.position().left+vlJlu*SVXYD.width();
kOJru-=vlJlu*SVXYD.width();
}
if(rAtgC<uBNjl)
{
VmkZm=SVXYD.position().left-vlJlu*SVXYD.width();
kOJru+=vlJlu*SVXYD.width();
}
SVXYD.css("z-index",1)
XcMJN.css("z-index",0)
XcMJN.css("left",VmkZm)
var YuHWc=waJSQuery(">.wa-gallery-image-contenair",XcMJN);
var XitrC=rAtgC*JVFCU
YuHWc.each(function(i)
{
if(XitrC+i<SQRHb)
{
hLCbx(waJSQuery(this),kpvpM,XitrC+i)
}
else
{
hLCbx(waJSQuery(this),kpvpM,null)
}
});



{
WIACt.animate({left:kOJru},ganPu,function(){
hOZAx(kpvpM,rAtgC)
});
}
}
function hOZAx(kpvpM,rAtgC)
{
var GGFvl=CXUII(kpvpM)
var SSLnk=(GGFvl==0)?1:0;
MKJqh(kpvpM,false)
kpvpM.data("page",rAtgC)
kpvpM.data("first-layout",SSLnk) 
var WIACt=kpvpM.find(".wa-gallery-scroll-pane");
var SVXYD=nXMHd(kpvpM,GGFvl);
var XcMJN=nXMHd(kpvpM,SSLnk);
SVXYD.css("left",SVXYD.position().left+WIACt.position().left)
XcMJN.css("left",XcMJN.position().left+WIACt.position().left)
WIACt.css("left",0)
SVXYD.hide()
MhkqK(kpvpM)
var XitrC=rAtgC*wAqli(kpvpM)
HKWMJ(kpvpM).data("current_image",XitrC);
xYDxc(kpvpM)
}
function KxixR(kpvpM)
{
var kgClC=HKWMJ(kpvpM);
var RxmUM=kpvpM.data("type_gallery")
var IxOEV=parseInt(kgClC.data("auto_diapo"))
return((RxmUM==1)&&(IxOEV==1)) 
}
function xYDxc(kpvpM)
{
var OQdgk=kpvpM.data("mode")
var RxmUM=kpvpM.data("type_gallery")
var OEBkW=kpvpM.find(".wa-gallery-navigation")
var GQvAH=HKWMJ(kpvpM);
var heVOZ=kpvpM.data("datas").global_config;
var KCdnb=kpvpM.find(".wa-gallery-comment-zone")
KCdnb.empty()
var emSxc=CsICf(kpvpM)
var WwnEc="";
if(OQdgk=="fullscreen")
{
if(heVOZ.comment_display_ImageNumber)
{
WwnEc+=(emSxc+1)+" / "+YCewR(kpvpM);
}
}
var jeuNB=FKkZm(kpvpM,emSxc,"link") 
if(WwnEc.length>0)
{
WwnEc+="<br>";
}
WwnEc+=FKkZm(kpvpM,emSxc,"comment")
WwnEc=WwnEc.replace(/<br>/gi,"\n")
WwnEc=waJSQuery.trim(WwnEc)
WwnEc=WwnEc.replace(/\n/gi,"<br>")
if((WwnEc.length==0)||(kpvpM.data("datas").global_config.show_comment==false))
{
KCdnb.hide()
return;
}
if((OQdgk=="normal")&&(RxmUM==1))
{
}
else
{
if((OQdgk!="fullscreen"))
{
KCdnb.hide()
return;
}
}
var ZHOUa=getWindowSize().width();
var fWgAT=getWindowSize().height();
var poblo=Ubkrn(kpvpM)
var HONNb=10;
KCdnb.css("padding",HONNb)
KCdnb.show()
if(isMSIE_lower_than_ie9())
{
KCdnb.append("<div class=\"wa-gallery-comment-bg\" style=\"position:absolute;background-color:#000000;filter:alpha(opacity=50); opacity:0.5;\"></div>")
}
KCdnb.append("<div class=\"wa-gallery-comment\" ></div>")
var FhLsC=80;
var aIWcJ=KCdnb.find(".wa-gallery-comment")
aIWcJ.css("width",poblo.width()) 
aIWcJ.html(WwnEc)
var friVb=aIWcJ.outerWidth(true)
var QrhQJ=aIWcJ.outerHeight(true)
var newHeight=Math.min(FhLsC,QrhQJ)
var EXdDa=waJSQuery(window).scrollLeft();
var oBxTl=waJSQuery(window).scrollTop();
var CiaEr=(ZHOUa-friVb)/2
var JSqWT=fWgAT-newHeight-2*HONNb
if(OQdgk=="fullscreen")
{
CiaEr+=EXdDa
JSqWT+=oBxTl
}
aIWcJ.css("left",CiaEr);
aIWcJ.css("height",newHeight);
aIWcJ.css("width",friVb);
KCdnb.css("left",0);
KCdnb.css("top",JSqWT);
KCdnb.css("width",ZHOUa);
KCdnb.css("height",newHeight+2*HONNb);
if((OQdgk=="normal")&&(RxmUM==1))
{
WwnEc=WwnEc.replace(/<br>/gi," ") 
aIWcJ.html(WwnEc)
var QijDi=0;
if(jeuNB.length>0)
{
QijDi=16;
}
var MiVvT=15+QijDi;
var PUoXT=kpvpM.width()
var bZXms=kpvpM.height()
aIWcJ.css("textAlign","left");
aIWcJ.css("left",0);
aIWcJ.css("top",0);
aIWcJ.css("height",MiVvT);
aIWcJ.css("width",PUoXT);
aIWcJ.css("fontSize",13);
aIWcJ.css("margin",3);
aIWcJ.css("overflow","hidden");
aIWcJ.css("whiteSpace","nowrap");
aIWcJ.css("textOverflow","ellipsis");
KCdnb.css("left",0);
KCdnb.css("top",bZXms-MiVvT-50);
KCdnb.css("width",PUoXT);
KCdnb.css("height",MiVvT);
var GGFvl=CXUII(kpvpM)
var SVXYD=nXMHd(kpvpM,GGFvl);
var liQoG=SVXYD.find(".wa-gallery-image");
var YuHWc=SVXYD.find(".wa-gallery-image-contenair");
var hUFLp=YuHWc.position().top+bZXms-35
var KqkBO=YuHWc.position().top+liQoG.height()-35-QijDi
var bYwcu=Math.min(hUFLp,KqkBO) 

KCdnb.css("top",bYwcu);
var EKiWT=(PUoXT-liQoG.width())/2
KCdnb.css("left",EKiWT);
aIWcJ.css("width",liQoG.width()-20);
KCdnb.css("width",liQoG.width()-20);
}
else
{
KCdnb.hide()
KCdnb.fadeIn()
}
if(isMSIE_lower_than_ie9())
{
var shXgj=KCdnb.find(".wa-gallery-comment-bg")
shXgj.css({"left":0,"top":0,"width":KCdnb.outerWidth(true),"height":KCdnb.outerHeight(true)});
}
}
function rdQZh(kpvpM,GXGOO)
{
var ImTYx=null
if(GXGOO["photos"])
{
ImTYx=GXGOO.photos
}
else
if(GXGOO["photoset"])
{
ImTYx=GXGOO.photoset
}
return ImTYx;
}
function FKkZm(kpvpM,ivUmM,hMuVT)
{
var ZrZEF=HKWMJ(kpvpM).data("3rdparty_datas")
if(ZrZEF)
{
var ZQrsf=kpvpM.data("config")
var GRMMc=ZQrsf.image_size;
var ImTYx=rdQZh(kpvpM,ZrZEF)
var uiFxn=ImTYx.photo[ivUmM]
var UoaxM=uiFxn.farm
var bRdSp=uiFxn.server
var VJclr=uiFxn.id
var hXBJm=uiFxn.secret 
if(hMuVT=="comment")
{
return uiFxn.title
}
var MiHMI=["t","s","m","z","l"]
var jblAI="";
var SUbZQ=0;
var DnYiL=0;
for(var i=0;i<MiHMI.length;i++)
{
var YgwAH=MiHMI[i]
var sOqvH=uiFxn["url_"+YgwAH]
if(sOqvH)
{
var ZHOUa=parseInt(uiFxn["width_"+YgwAH])
var fWgAT=parseInt(uiFxn["height_"+YgwAH])
if((jblAI.length==0)||((ZHOUa>SUbZQ)&&(fWgAT>DnYiL)))
{
jblAI=sOqvH;
SUbZQ=ZHOUa
DnYiL=fWgAT
}
}
}
if(hMuVT=="th")
{
var rtdhW=""
for(var i=0;i<MiHMI.length;i++)
{
var YgwAH=MiHMI[i]
var sOqvH=uiFxn["url_"+YgwAH]
if(sOqvH)
{
var ZHOUa=parseInt(uiFxn["width_"+YgwAH])
var fWgAT=parseInt(uiFxn["height_"+YgwAH])
rtdhW=sOqvH
if((ZHOUa>GRMMc)&&(fWgAT>GRMMc))
{
break;
}
}
}
return rtdhW;
}
if(hMuVT=="big")
{
return jblAI 
}
if(hMuVT=="sl_img")
{
return jblAI 
}
if(hMuVT=="src")
{
return jblAI 
}
if(hMuVT=="size")
{
return new Size(SUbZQ,DnYiL)
}
return ""
}
if(ivUmM>=kpvpM.data("datas").images.length)
{
return ";"
}
var uiFxn=kpvpM.data("datas").images[ivUmM]
var vljpJ=kpvpM.data("folder");
if(hMuVT=="th")
{
return vljpJ+"th_"+uiFxn.fn+"?"+uiFxn.mod_th
}
if(hMuVT=="big")
{
return vljpJ+"big_"+uiFxn.fn+"?"+uiFxn.mod
}
if(hMuVT=="sl_img")
{
return vljpJ+"sl_"+uiFxn.fn+"?"+uiFxn.mod
}
if(hMuVT=="src")
{
return vljpJ+uiFxn.fn+"?"+uiFxn.mod
}
if(hMuVT=="size")
{
return new Size(uiFxn.size.w,uiFxn.size.h)
}
if(hMuVT=="link")
{
if(uiFxn.lnk&&(uiFxn.lnk.url.length>0))
{
var wOMej=uiFxn.lnk.url;
return wOMej;
}
return "";
}
if(hMuVT=="comment")
{
var aIWcJ=""
if(uiFxn.comment)
aIWcJ+=uiFxn.comment
aIWcJ=aIWcJ.replace(/\n/gi,"<br>")
if(aIWcJ.length>0)aIWcJ+="<br>"
if(uiFxn.lnk&&(uiFxn.lnk.url.length>0))
{
var wOMej=uiFxn.lnk.url;
var cQGrV=waJSONLinkToOnClick(uiFxn.lnk)
aIWcJ+="<div class='wa-gallery-comment-link' "+cQGrV+" >"+wOMej+"</div>"
}
return aIWcJ;
}
if(hMuVT=="tooltip")
{
return(uiFxn.tooltip)
}
}
function hLCbx(kaNPK,kpvpM,wSBmM)
{
var GQvAH=HKWMJ(kpvpM);
var heVOZ=kpvpM.data("datas").global_config;
var RxmUM=kpvpM.data("type_gallery");
var ecfIV=waJSQuery(">.wa-dyn-loader",kaNPK);
waActivateDynamicLoader(kaNPK)
var liQoG=waJSQuery(">.wa-gallery-image",kaNPK);
if(wSBmM==null)
{
ecfIV.hide()
liQoG.hide()
kaNPK.hide()
return;
}
ecfIV.show()
liQoG.hide() 
kaNPK.show()
var MJITJ=false;
var OQdgk=kpvpM.data("mode")
var vljpJ=kpvpM.data("folder");
var LUENo="";
var ZZqsZ=extractParamInfo(GQvAH,"source")
var mDHWb=kWEnb(kpvpM);
if((OQdgk=="normal")&&(RxmUM==0))
{
MJITJ=true;
}
if((OQdgk=="normal")&&(RxmUM==1)&&(heVOZ.open_popup_when_clicking==true))
{
MJITJ=true;
}

if((OQdgk=="fullscreen")||(mDHWb==false))
{
var ZHOUa=getWindowSize().width();
var fWgAT=getWindowSize().height();
var HONNb=25;
var BlspN=0;
if(mDHWb==false)
{
ZHOUa=kpvpM.width();
fWgAT=kpvpM.height();
HONNb=heVOZ.inner_slideshow_image_margin;
}
var LPVZu=new Size(ZHOUa-2*HONNb,fWgAT-2*HONNb-BlspN)
var qqLBX=FKkZm(kpvpM,wSBmM,"size");
var dZUZP=(((RxmUM==1)||(RxmUM==2))&&(heVOZ.fit_image_to_slideshow==true));
var HVCei=true;
if((OQdgk=="normal")&&dZUZP)
{
HVCei=false;
}
if(HVCei)
{
qqLBX.scale(LPVZu)
}
else
{
qqLBX=new Size(kpvpM.width(),kpvpM.height());
}
if(OQdgk=="fullscreen")
{
var poblo=Ubkrn(kpvpM)
qqLBX.scale(poblo)
}
if(OQdgk=="normal")
{
LUENo=FKkZm(kpvpM,wSBmM,"sl_img");
}
else
{
LUENo=FKkZm(kpvpM,wSBmM,"big");
}
var drxHL=false;
if(ZZqsZ.length>0)
{
if(dZUZP)
{
drxHL=true;
}

}
liQoG.css("width",qqLBX.width())
liQoG.css("height",qqLBX.height())
kaNPK.css("width",qqLBX.width())
kaNPK.css("height",qqLBX.height())
if(drxHL)
{
var sVuul=FKkZm(kpvpM,wSBmM,"size");
var EspFp=sVuul;
EspFp.scaleByExpanding(qqLBX.clone())
liQoG.css("width",EspFp.width())
liQoG.css("height",EspFp.height())
var hbfRq=-(EspFp.width()-qqLBX.width())/2;
var XuBVZ=-(EspFp.height()-qqLBX.height())/2;
liQoG.css({"left":hbfRq,"top":XuBVZ})
}
var CiaEr=Math.round((ZHOUa-qqLBX.width())/2)
var JSqWT=Math.round((fWgAT-BlspN-qqLBX.height())/2)
var EXdDa=waJSQuery(window).scrollLeft();
var oBxTl=waJSQuery(window).scrollTop();
if(OQdgk!="normal")
{
CiaEr+=EXdDa
JSqWT+=oBxTl
}
kaNPK.css("left",CiaEr)
kaNPK.css("top",JSqWT)
}
else
{
var EchWR=false;
if(ZZqsZ.length>0)
{
EchWR=true;
}
if(EchWR)
{
var ZQrsf=kpvpM.data("config")
var GRMMc=ZQrsf.image_size;
var lgXlN=new Size(GRMMc,GRMMc)
var qqLBX=FKkZm(kpvpM,wSBmM,"size");
var EspFp=qqLBX.clone();
EspFp.scaleByExpanding(lgXlN) 
if(EspFp.width()==EspFp.height())
{
var bNMgE=Math.min(GRMMc,qqLBX.width())
var XNBpP=Math.min(GRMMc,qqLBX.height())
liQoG.css({"width":bNMgE,"height":XNBpP,"clip":"rect(auto auto auto auto)","left":(lgXlN.width()-bNMgE)/2,"top":(lgXlN.height()-XNBpP)/2});
}
else
{
liQoG.css({width:EspFp.width(),height:EspFp.height()});
if(EspFp.width()>EspFp.height())
{
var pmFdi=Math.floor((EspFp.width()-lgXlN.width())/2);;
liQoG.css({"left":-pmFdi,"top":(lgXlN.height()-EspFp.height())/2,"clip":"rect(auto "+(EspFp.width()-pmFdi)+"px auto "+pmFdi+"px)"});
}
else
{
var mcIZP=Math.floor((EspFp.height()-lgXlN.height())/2);;
liQoG.css({"left":(lgXlN.width()-EspFp.width())/2,"top":-mcIZP,"clip":"rect("+mcIZP+"px auto "+(EspFp.height()-mcIZP)+"px auto)"});
}
}
}
LUENo=FKkZm(kpvpM,wSBmM,"th");
}
kaNPK.css('cursor',(MJITJ)?'pointer':'Default');
var TSkas=liQoG.attr("src")
if(TSkas!=LUENo)
{
liQoG.load(function(){
var liQoG=waJSQuery(this);
ecfIV.hide()
liQoG.show()
});
}
else
{
ecfIV.hide()
liQoG.show()
}
liQoG.attr("title",FKkZm(kpvpM,wSBmM,"tooltip"))
liQoG.attr("src",LUENo)
ecfIV.css("left",(liQoG.width()-ecfIV.width())/2)
ecfIV.css("top",(liQoG.height()-ecfIV.height())/2)
}
function eBgNn(kpvpM)
{
var kgClC=HKWMJ(kpvpM);
var IxOEV=parseInt(kgClC.data("auto_diapo"))
var RxmUM=parseInt(kgClC.data("type_gallery"))
var SQRHb=YCewR(kpvpM)
if(isMSIE()) 
{
kpvpM.css("background-image","url(wa_transparent.gif)")
}
var OQdgk=kpvpM.data("mode")
var ZQrsf=kpvpM.data("config")
var heVOZ=kpvpM.data("datas").global_config
var kpRGC=""
kpRGC+="<div style=\"position:absolute;left:"+ZQrsf.margin_left+"px;top:"+ZQrsf.margin_top+"px;padding:0px;";
kpRGC+="width:"+kpvpM.width()+"px;\" class=\"wa-gallery-page\">"
var llDLW="" 

if(ZQrsf.has_shadow)
{
llDLW+="wa-gallery-shadow "
}
var n=0;
var SITJT=ZQrsf.image_spacing;
for(var BgXRT=0;BgXRT<ZQrsf.rows;BgXRT++)
{
var QJeup=ZQrsf.image_spacing;
for(var FZbhn=0;FZbhn<ZQrsf.cols;FZbhn++)
{
kpRGC+="<div class='wa-gallery-image-contenair "+llDLW+"' style=\"position:absolute;left:"+QJeup+"px;top:"+SITJT+"px;width:"+ZQrsf.image_size+"px;height:"+ZQrsf.image_size+"px;\">"
kpRGC+="<img class='wa-gallery-image' style=\"position:absolute;left:0px;top:0px;width:"+ZQrsf.image_size+"px;height:"+ZQrsf.image_size+"px;border:none;\"/>" 
kpRGC+=htmlDynamicLoader(true,kpvpM.width(),kpvpM.height()) 
kpRGC+="</div>"
QJeup+=ZQrsf.image_size+2*ZQrsf.image_spacing
if(n>SQRHb)
{
break
}
n++;
}
SITJT+=ZQrsf.image_size+2*ZQrsf.image_spacing
}
kpRGC+="</div>";
var WIACt=kpvpM.find(".wa-gallery-scroll-pane")
WIACt.append(kpRGC);
WIACt.append(kpRGC);
var SVXYD=nXMHd(kpvpM,0);
var vljpJ=kpvpM.data("folder");
if(kpvpM.data("datas")==undefined)
{
alert("_folder="+vljpJ)
}
var JhvkZ=ZQrsf.default_selected_image;
var eGcWP=0;
if(JhvkZ)
{
eGcWP=Math.floor(JhvkZ/wAqli(kpvpM))
}
kpvpM.data("page",eGcWP)
var YuHWc=waJSQuery(">.wa-gallery-image-contenair",SVXYD);
var XitrC=CsICf(kpvpM)*wAqli(kpvpM)
YuHWc.each(function(i)
{
if(XitrC+i<SQRHb)
{
hLCbx(waJSQuery(this),kpvpM,XitrC+i)
}
else
{
hLCbx(waJSQuery(this),kpvpM,null)
}
});
var XcMJN=nXMHd(kpvpM,1);
XcMJN.hide() 
var tdnxv=kpvpM.find(".wa-gallery-page")
var ZuMWm=true;
if((RxmUM==1)||(RxmUM==2))
{
ZuMWm=false;
if(heVOZ.open_popup_when_clicking)
{
ZuMWm=true;
}
}
if(ZuMWm)
tdnxv.each(function(i)
{
var YuHWc=waJSQuery(">.wa-gallery-image-contenair",waJSQuery(this));
YuHWc.each(function(i)
{
var liQoG=waJSQuery(this) 
liQoG.css("cursor","pointer")
liQoG.click(function(){
var eGcWP=CsICf(kpvpM)
var KmpYq=wAqli(kpvpM)
var emSxc=KmpYq*eGcWP+i
BntnV(kpvpM,emSxc)
return false 
});
});
});
var OEBkW=kpvpM.find(".wa-gallery-navigation")
var lXEXA="wa-gallery-bt-design wa-gallery-button "
lXEXA+=(OQdgk=="normal")?"wa-gallery-bt-action-mini wa-gallery-corner-mini":"wa-gallery-bt-action-big wa-gallery-corner-big"
var dRJKO=""
dRJKO+=(OQdgk=="normal")?"wa-gallery-button wa-gallery-bt-design-arrow wa-gallery-arrow-mini wa-gallery-corner-mini":"wa-gallery-bt-design-arrow"
OEBkW.append("<div class=\"wa-gallery-comment-zone\"></div>") 
if(KxixR(kpvpM)==false)
{
OEBkW.append("<div class=\"wa-gallery-arrow  param[type(prev)] "+dRJKO+"\"></div>")
OEBkW.append("<div class=\"wa-gallery-arrow param[type(next)] "+dRJKO+"\"></div>")
OEBkW.append("<div class=\"wa-gallery-bt-action param[type(act-close)] wa-gallery-bt-corner\"></div>")
OEBkW.append("<div class=\"wa-gallery-bt-action param[type(act-list)] wa-gallery-bt-corner\"></div>")
OEBkW.append("<div class=\"wa-gallery-bt-action param[type(act-diapo)] wa-gallery-bt-corner\"></div>")
}
var suTGU="wa-gallery-bt-design "
suTGU=""
suTGU+=(OQdgk=="normal")?"wa-gallery-page-selector-mini wa-gallery-corner-mini":"wa-gallery-page-selector-big wa-gallery-corner-big"
OEBkW.append("<div style='position:absolute;' class=\"wa-gallery-page-selector "+suTGU+"\"></div>")
kpvpM.find(".wa-gallery-arrow").each(function(i)
{
var MsAcG=waJSQuery(this);
var RGePW=extractParamInfo(MsAcG,"type")
if(RGePW=="prev")
{
MsAcG.html("<img class='wa-gallery-arrow-left' style='display:none' src=\"wa_fancybox/fancy_nav_left.png\" border=0>")
}
else
{
MsAcG.html("<img class='wa-gallery-arrow-right' style='display:none' src=\"wa_fancybox/fancy_nav_right.png\" border=0>")
}
MsAcG.click(function() 
{
var GQvAH=MsAcG.parents(".wa-gallery");
nXMHd(GQvAH,0)
var kpvpM=waJSQuery(this)
var vpFmW=CsICf(GQvAH)
var DpuWk=(RGePW=="next")?(vpFmW+1):(vpFmW-1);
KBTRN(GQvAH,DpuWk)
return false
});
{
var oUArS=MsAcG.find("img")
oUArS.fadeOut()
MsAcG.hover(function()
{
oUArS.stop(true,true).fadeIn()
},function()
{
oUArS.stop(true,true).fadeOut()
});
}
});
kpvpM.find(".wa-gallery-bt-action").each(function(i)
{
var MsAcG=waJSQuery(this);
var RGePW=extractParamInfo(MsAcG,"type")
MsAcG.css({"width":41,"height":28}) 
if(RGePW=="act-diapo")
{
MsAcG.html("<img src='wa_gallery/wa_bt_start_diapo.png' border=0>")
}
else
if(RGePW=="act-list")
{
MsAcG.html("<img src='wa_gallery/wa_bt_list.png' border=0>")
}
else
if(RGePW=="act-close")
{
MsAcG.css({"width":30,"height":30})
MsAcG.html("<img src='wa_fancybox/fancy_close.png' border=0>")
}
centerElement(MsAcG,"div")
MsAcG.click(function()
{
var GQvAH=MsAcG.parents(".wa-gallery");
lZqwx(GQvAH)
if(RGePW=="act-list")
{
var wDhKX=CsICf(GQvAH)*wAqli(GQvAH)
HKWMJ(GQvAH).data("fullscreen_contenair","windows");
loadFullscreen("fullscreen_list",wDhKX)
}
if(RGePW=="act-diapo")
{
brFIl(HKWMJ(GQvAH))
}
if(RGePW=="act-close")
{
closeFullscreen()
}
return false;
});
});
if(OQdgk=="normal")
{
if(heVOZ.always_display_nav_elements)
{
Gbuwi(kpvpM,true)
}
else
{
kpvpM.hover(function(){Gbuwi(waJSQuery(this),true);},function(){Gbuwi(waJSQuery(this),false);});
Gbuwi(kpvpM,false)
}
}
else
{
Gbuwi(kpvpM,true)
}
MKJqh(kpvpM,false)
if(HKWMJ(kpvpM).data("auto_diapo")==1)
{
huoPV(kpvpM)
}
else
{
MhkqK(kpvpM)
}
centerGalleryContainer();
var hfWId=document.wa_global_query_info
if(hfWId)
{
if(hfWId.m_unid+"/"==vljpJ)
{
BntnV(kpvpM,hfWId.m_index_item) 
}
}
}
function Gbuwi(kpvpM,GIgNM)
{
if(GIgNM==kpvpM.data("_is_visible"))
{
return;
}
var OQdgk=kpvpM.data("mode")
var ZQrsf=kpvpM.data("config")
var heVOZ=kpvpM.data("datas").global_config
var RxmUM=kpvpM.data("type_gallery");
kpvpM.data("_is_visible",GIgNM);
if(heVOZ.always_display_nav_elements&&(GIgNM==false))
{
return;
}
{
if(isMSIE_lower_than_ie9())
{
var OEBkW=kpvpM.find(".wa-gallery-navigation");
var cOnDk=OEBkW.children()
if(GIgNM)
{
cOnDk.stop(true,true).fadeIn();
MhkqK(kpvpM)
}
else
{
cOnDk.stop(true,true).fadeOut()
}
}
else
{
var OEBkW=kpvpM.find(".wa-gallery-navigation");
var cOnDk=OEBkW.children()
if(GIgNM)
{
cOnDk.stop(true,true).fadeIn();
MhkqK(kpvpM)
}
else
{
cOnDk.stop(true,true).fadeOut()
}
}
}
xYDxc(kpvpM)
}
function MhkqK(kpvpM)
{
var OEBkW=kpvpM.find(".wa-gallery-navigation")
if(document.internalPreview)
{
OEBkW.hide()
return;
}
var GQvAH=kpvpM;
var RxmUM=kpvpM.data("type_gallery");
var OQdgk=kpvpM.data("mode")
var uKSMR=RxmUM>0
var heVOZ=kpvpM.data("datas").global_config
var ZuMWm=true;
if((RxmUM==1)||(RxmUM==2))
{
ZuMWm=false;
if(heVOZ.open_popup_when_clicking)
{
ZuMWm=true;
}
}
var EDLSn=(OQdgk=="fullscreen")||((OQdgk=="normal")&&(ZuMWm==false)) 
var SQRHb=YCewR(kpvpM);
var oMpVM=xAvoa(kpvpM);
var PUoXT=kpvpM.width()
var bZXms=kpvpM.height()
if((OQdgk=="fullscreen")||(OQdgk=="fullscreen_list"))
{
PUoXT=getWindowSize().width()
bZXms=getWindowSize().height()
}
var xxpTC=mrFcs(kpvpM) 
var fFaed=Math.min(PUoXT,xxpTC)
var Glkpu=Math.min(bZXms,xxpTC)
if((OQdgk=="fullscreen")||(OQdgk=="fullscreen_list"))
{
var poblo=Ubkrn(kpvpM)
fFaed=poblo.width()
Glkpu=poblo.height()
}
var HONNb=10;
var pKUNG=3;
var CiaEr=(PUoXT-fFaed)/2+HONNb
var sGKHY=(PUoXT-fFaed)/2+fFaed-HONNb
var JSqWT=(bZXms-fFaed)/2+HONNb
var EXdDa=waJSQuery(window).scrollLeft();
var oBxTl=waJSQuery(window).scrollTop();
if(OQdgk=="normal")
{
CiaEr=pKUNG
sGKHY=PUoXT-pKUNG
}
if(OQdgk=="fullscreen_list")
{
CiaEr=HONNb
sGKHY=PUoXT-HONNb
}
var GGFvl=CXUII(kpvpM)
var SVXYD=nXMHd(kpvpM,GGFvl);
var liQoG=SVXYD.find("img")
var SCPdC=liQoG.width();
SCPdC=Math.max(SCPdC,150) 
kpvpM.find(".wa-gallery-arrow").each(function(i)
{
var MsAcG=waJSQuery(this);
var oUArS=MsAcG.find("img") 
var RGePW=extractParamInfo(MsAcG,"type")
var uBNjl=CsICf(GQvAH);
var ruQhL=10
var nkiCL=0;
var qGish=(bZXms-MsAcG.height())/2;
var ZffGI=0;
if(EDLSn)
{
if(OQdgk=="normal")
{
MsAcG.css({"width":PUoXT/3,"height":bZXms})
}
else
{
MsAcG.css({"width":liQoG.width()/3,"height":liQoG.height()*2/3})
}
}
else
{
if(OQdgk=="normal")
{
MsAcG.css({"height":bZXms})
}
else
{
MsAcG.css({"height":liQoG.height()*2/3})
}
}

if(RGePW=="prev")
{
nkiCL=CiaEr
ZffGI=0;
if(OQdgk=="normal")
{
nkiCL=0
}
else
{
nkiCL=(PUoXT-SCPdC)/2
}
qGish=(bZXms-MsAcG.height())/2
ZffGI=ruQhL
if(uBNjl==0)
{
oUArS.hide();
MsAcG.hide();
}
else
MsAcG.show();
}
else
{
nkiCL=sGKHY-MsAcG.width()
ZffGI=(MsAcG.width()-30)
if(OQdgk=="normal")
{
nkiCL=PUoXT-MsAcG.width();
}
else
{
nkiCL=(PUoXT-SCPdC)/2+SCPdC-MsAcG.width()
}
qGish=(bZXms-MsAcG.height())/2
ZffGI=MsAcG.width()-30-ruQhL
if(uBNjl>=xAvoa(kpvpM)-1)
{
oUArS.hide();
MsAcG.hide();
}
else MsAcG.show();
}
if((OQdgk=="fullscreen")||(OQdgk=="fullscreen_list"))
{
nkiCL=EXdDa+nkiCL
qGish=oBxTl+qGish
}
MsAcG.css({"left":nkiCL,"top":qGish})
if(isMSIE())
{
MsAcG.css("background-image","url(wa_transparent.gif)")
}
oUArS.css({"position":"absolute","left":ZffGI,"top":(MsAcG.height()-30)/2})
if(SIhLa(kpvpM))
{
oUArS.hide();
MsAcG.hide();
}
});
var UPtqY=kpvpM.find(".wa-gallery-page-selector")
if((heVOZ.type_display_page_navigator!=0)&&(oMpVM>1) &&((OQdgk=="normal")||(OQdgk=="fullscreen_list")))
{
var SOHLA=false;
var HWGmk=20;
var YFKrm=20;
var CFksq=YFKrm
var QBTlE=12 
var wfQGL=PUoXT-2*QBTlE;

var EPVME=HWGmk*oMpVM+2*QBTlE
if(EPVME>wfQGL)
{
SOHLA=false;
CFksq=30
}
else
{
SOHLA=true;
YFKrm=HWGmk;
CFksq=30
}
var htDdo=YFKrm*oMpVM+2*QBTlE
wfQGL=Math.min(wfQGL,htDdo)
UPtqY.css("height",CFksq)
UPtqY.html("<div style='position:absolute;' class='wa-gallery-page-selector-inner'></div>")
var UtZhd=UPtqY.find(".wa-gallery-page-selector-inner")
if(SOHLA)
{
}
else
{
UtZhd.css({"background-color":"#000000","opacity":0.8,"border":"1px solid rgba(220,220,220,0.7)","border-radius":4})
}
var MLcmS=CsICf(kpvpM);
var aoKmE=YFKrm
var eItgT=Math.floor(wfQGL/YFKrm) 
eItgT=Math.min(eItgT,oMpVM)
if(eItgT>1)
{
if(OQdgk=="normal")
{
var hauJZ=2 
if(heVOZ.type_display_page_navigator==1) 
{
UPtqY.css("top",bZXms-UPtqY.height()-hauJZ)
}
else
if(heVOZ.type_display_page_navigator==2) 
{
UPtqY.css("top",bZXms)
}
}
else
{
UPtqY.css("top",bZXms-50)
}
UPtqY.css("width",wfQGL)
UPtqY.css("left",(PUoXT-UPtqY.width())/2) 
UtZhd.css({"width":wfQGL,"height":YFKrm,"top":CFksq-YFKrm}) 
var AiUgY=Math.ceil(MLcmS-(eItgT/2))
AiUgY=Math.max(AiUgY,0)
var jEPmJ=AiUgY+eItgT
jEPmJ=Math.min(jEPmJ,oMpVM)
if(jEPmJ-eItgT>=0)
{
AiUgY=jEPmJ-eItgT
}
var xBut=(wfQGL-(eItgT*YFKrm))/2
var OjEXY="";
for(var i=0;i<eItgT;i++)
{
var wSBmM=AiUgY+i;
if(wSBmM<oMpVM)
{
if(SOHLA)
{
OjEXY+="<div class='wa-gallery-page-selector-bt-design' style='vertical-align:middle;line-height:"+aoKmE+"px;' ></div>";
}
else
{
OjEXY+="<div class='wa-gallery-page-selector-bt-design' style='vertical-align:middle;line-height:"+aoKmE+"px;' >"+(wSBmM+1)+"</div>";
}
}
}
UtZhd.html(OjEXY)
var Onqkc=UPtqY.find(".wa-gallery-page-selector-bt-design") 
Onqkc.each(function(i){
var MsAcG=waJSQuery(this)
var wSBmM=AiUgY+i;
if(SOHLA)
{
if(MLcmS==wSBmM)
{
MsAcG.html("<img src='wa_gallery/wa_navigation_past_on.png' border=0>")
}
else
{
MsAcG.html("<img src='wa_gallery/wa_navigation_past_off.png' border=0>")
}
}
else
{
if(MLcmS==wSBmM)
{
MsAcG.css({"font-size":"14px","font-weight":"bold"})
}
else
{
MsAcG.css({"font-size":"12px","font-weight":"normal"})
}
}
MsAcG.css({"left":xBut,"top":0,"width":YFKrm,"height":aoKmE})
xBut+=YFKrm;
if(MLcmS!=wSBmM)
{
MsAcG.click(function()
{
KBTRN(kpvpM,wSBmM);
return false
})
}
}) 
}
else
{
UPtqY.hide();
}
}
else
{
UPtqY.hide();
}
var iHBKj=0;
var HdifQ=0;
var Xredk=0;
var HONNb=10;
if((OQdgk=="normal")||(OQdgk=="fullscreen_list"))
{
if(OQdgk=="normal")
{
iHBKj=PUoXT
HdifQ=0
}
if(OQdgk=="fullscreen_list")
{
iHBKj=PUoXT-HONNb
HdifQ=HONNb
}
}
else
{
var vUOIK=Ubkrn(kpvpM);
iHBKj=(PUoXT-vUOIK.width)/2+vUOIK.width
HdifQ=(bZXms-vUOIK.height)/2
}
var TUODb=6;
kpvpM.find(".wa-gallery-bt-action").each(function(i)
{
var MsAcG=waJSQuery(this);
var RGePW=extractParamInfo(MsAcG,"type")
var KbCZr=false;
var pcbHg=true 
if(RGePW=="act-list")
{
if(heVOZ.has_fullscreen_thumbnail_mode)
{
KbCZr=((SIhLa(kpvpM)==false)&&(OQdgk=="fullscreen")&&(xAvoa(kpvpM)>1))
}
}
if(RGePW=="act-diapo")
{
{
KbCZr=((SIhLa(kpvpM)==false)&&(OQdgk=="fullscreen")&&(xAvoa(kpvpM)>1)&&(heVOZ.show_diaporama_button==true))
}
}
var mDHWb=kWEnb(kpvpM);
if(RGePW=="act-close")
{
KbCZr=(OQdgk!="normal")&&(SIhLa(kpvpM)==false)&&(mDHWb==true)
if(OQdgk=="fullscreen")
{
pcbHg=false;
}
}
if(KbCZr&&pcbHg)
{
var UKQwM=MsAcG.width()+TUODb
Xredk+=UKQwM
iHBKj-=UKQwM
}
MsAcG.css("top",HdifQ-MsAcG.height()-2)
MsAcG.css("left",iHBKj)
if(KbCZr) MsAcG.show();else MsAcG.hide();
MsAcG.data("wa_is_visible",KbCZr)
});
if((OQdgk=="fullscreen")||(OQdgk=="fullscreen_list"))
{
var glqmr=(PUoXT-Xredk)/2
var GGFvl=CXUII(kpvpM)
var SVXYD=nXMHd(kpvpM,GGFvl);
var liQoG=SVXYD.find("img")
var buWwW=(PUoXT-liQoG.width())/2+liQoG.width();
kpvpM.find(".wa-gallery-bt-action").each(function(i)
{
var MsAcG=waJSQuery(this);
if(MsAcG.data("wa_is_visible"))
{
var RGePW=extractParamInfo(MsAcG,"type")
var pcbHg=true
if(OQdgk=="fullscreen")
{
pcbHg=false;
}
var nkiCL=0;
var qGish=0;
var tFOSf=MsAcG.width();
if(pcbHg)
{
nkiCL=glqmr;
if(OQdgk=="fullscreen")
{
qGish=Math.max(5,JSqWT-30)
}
if(OQdgk=="fullscreen_list")
{
qGish=5;
}
glqmr+=tFOSf+TUODb
}
else
{
if(RGePW=="act-close")
{
buWwW=buWwW-tFOSf/2
nkiCL=buWwW
qGish=(bZXms-liQoG.height())/2-MsAcG.height()/2
}
if(RGePW=="act-list")
{
buWwW=buWwW-5
buWwW=buWwW-tFOSf
nkiCL=buWwW
qGish=(bZXms-liQoG.height())/2-MsAcG.height()/2
}
if(RGePW=="act-diapo")
{
buWwW=buWwW-5
buWwW=buWwW-tFOSf
nkiCL=buWwW
qGish=(bZXms-liQoG.height())/2-MsAcG.height()/2
}
}
nkiCL+=EXdDa
qGish+=oBxTl
MsAcG.css({"left":nkiCL,"top":qGish})
}
})
}
}
function Ubkrn(kpvpM)
{
var HONNb=10;
var ZHOUa=getWindowSize().width();
var fWgAT=getWindowSize().height();
if(isIPhone())
{
return new Size(ZHOUa-2*HONNb,fWgAT-2*HONNb);
}
var xxpTC=mrFcs(kpvpM) 
return new Size(Math.min(xxpTC,ZHOUa-2*HONNb),Math.min(xxpTC,fWgAT-2*HONNb))
}
function mrFcs(kpvpM)
{
var xxpTC=kpvpM.data("datas").global_config.max_image_resolution
if(xxpTC==-1) xxpTC=6000;
return xxpTC
}
function VcBmB(url,KmOPp,DcOjp)
{
var e=document.createElement("script");
e.src=url;
e.type="text/javascript";
e.onerror=function(){

}
if(/msie/i.test(navigator.userAgent)&&!/opera/i.test(navigator.userAgent)){
e.onreadystatechange=function(){
if((this.readyState=='complete')||(this.readyState=='loaded')){
KmOPp(DcOjp)
}
}
}else
{
e.onload=function(){
KmOPp(DcOjp)
}
}
document.getElementsByTagName("head")[0].appendChild(e);
}
function wa_jsonFlickrApi(ZrZEF)
{
document.wa_current_datas_gallery=ZrZEF
}
function tfuuu(DcOjp)
{
var kpvpM=DcOjp.objGallery 
var EjnJm=DcOjp.config
var GROls=DcOjp.idAlbum
var json=DcOjp.json 
{
var ZrZEF=document.wa_current_datas_gallery
if(ZrZEF==null)
{
return;
}
if(ZrZEF.stat=="fail")
{
return;
}
HKWMJ(kpvpM).data("3rdparty_datas",ZrZEF)
kpvpM.data("datas",json)
if(!EjnJm) EjnJm=kpvpM.data("datas").normal_config;
kpvpM.data("config",EjnJm)
kpvpM.data("folder",GROls+"/")
eBgNn(kpvpM);
}
}
function SPfgC(kpvpM,EjnJm)
{
MKJqh(kpvpM,true)
var GROls=extractParamInfo(kpvpM,"config_key")
var YPZhp=extractParamInfo(kpvpM,"modif_id") 
var ZZqsZ=extractParamInfo(HKWMJ(kpvpM),"source") 
var sPXgJ="";
if(GROls.length>0)
{
sPXgJ=GROls+"/photo-album-definition" 
var WWUes=Translator.m_lang_for_filename
if(WWUes.length>0)
{
WWUes="_"+WWUes;
}
sPXgJ+=WWUes+".js"
sPXgJ+="?t="+YPZhp
}




function TgRSr(json)
{
var RxmUM=kpvpM.data("type_gallery");
var OQdgk=kpvpM.data("mode")
var ZZqsZ=extractParamInfo(HKWMJ(kpvpM),"source") 
var MZmOD=null
if(ZZqsZ=="flickr")
{
var qUBRM=extractParamInfo(HKWMJ(kpvpM),"user_id") 
var SXlHl=extractParamInfo(HKWMJ(kpvpM),"album") 
var ncqSq="flickr.people.getPublicPhotos"
if(SXlHl.length>0)
{
ncqSq="flickr.photosets.getPhotos"
}
MZmOD="http://api.flickr.com/services/rest/?method="+ncqSq+"&api_key=624245e80423b78999b7037a68645766&user_id="+qUBRM
MZmOD+="&extras=url_t, url_s, url_m, url_z, url_l, url_o" 
MZmOD+="&format=json"
MZmOD+="&privacy_filter=1"
MZmOD+="&photoset_id="+SXlHl
MZmOD+="&jsoncallback=wa_jsonFlickrApi"
}
var ZrZEF=HKWMJ(kpvpM).data("3rdparty_datas")
if((MZmOD)&&(ZrZEF==undefined))
{
var DcOjp={objGallery:kpvpM,"config":EjnJm,"idAlbum":GROls,"json":json}

VcBmB(MZmOD,tfuuu,DcOjp) 
return;
}
kpvpM.data("datas",json)
if(!EjnJm) EjnJm=kpvpM.data("datas").normal_config;
kpvpM.data("config",EjnJm)
kpvpM.data("folder",GROls+"/")
eBgNn(kpvpM);
if(isMobileBrowser())
{
kpvpM.touchwipe({
wipeLeft:function(){
ZAaGm(kpvpM)
return false
},wipeRight:function(){
eKEQf(kpvpM)
return false
},preventDefaultEvents:true
})
}
if(OQdgk!="normal")
{
if(waJSQuery.fn.mousewheel)
{
kpvpM.bind('mousewheel.fb',function(e,delta)
{
e.preventDefault();
if(delta>0)
{
eKEQf(kpvpM)
}
else
{
ZAaGm(kpvpM)
}
});
}
}
}
if(GROls.length==0)
{

TgRSr(waPreviewJsonGalleryDatas)
}
else
{
waJSQuery.getJSON(sPXgJ,{},TgRSr)
}
}
function TMGaX(kpvpM,e)
{
var OQdgk=kpvpM.data("mode")
if(OQdgk=="normal") return;
if(e.which=='27')
{
closeFullscreen()
e.preventDefault();
}
if(SIhLa(kpvpM)==false)
{
if(e.which=='37')
{
eKEQf(kpvpM)
e.preventDefault();
}
if(e.which=='39')
{
ZAaGm(kpvpM)
e.preventDefault();
}
}
}
function initializeAllWA_gallery()
{
waJSQuery(".wa-gallery").each(function(index)
{
var kpvpM=waJSQuery(this)
kpvpM.data("mode","normal") 
var RxmUM=parseInt(extractParamInfo(kpvpM,"type_gallery"))
var IxOEV=parseInt(extractParamInfo(kpvpM,"auto_diapo"))
kpvpM.data("type_gallery",RxmUM)
kpvpM.data("auto_diapo",IxOEV)
if(RxmUM==1)
{
var EjnJm={
"rows":1,"cols":1,"image_size":100,"image_spacing":0,"nb_images_per_page":1,"margin_left":0,"margin_top":0,"default_selected_image":0,"has_shadow":false
}
SPfgC(kpvpM,EjnJm)
}
else
{
SPfgC(kpvpM)
}
});
waJSQuery(window).keydown(function(e){
var kpvpM=waJSQuery(".wa-fullscreen-contenair").find(".wa-gallery")
if(kpvpM&&(kpvpM.length>0))
{
TMGaX(kpvpM,e)
}
});
}
function lZqwx(kpvpM)
{
var OQdgk=kpvpM.data("mode")
if(OQdgk=="normal")
{
waJSQuery(document).data("origin_fullscreen_gallery",kpvpM)
}
}
function afCNQ(kpvpM)
{
var kgClC=HKWMJ(kpvpM)
var XitrC=HKWMJ(kpvpM).data("current_image");
var OQdgk=kpvpM.data("mode")
loadFullscreen(OQdgk,XitrC)
}
function BntnV(kpvpM,ivUmM)
{
if(SIhLa(kpvpM)) return;
var OQdgk=kpvpM.data("mode")
if((OQdgk=="normal")||(OQdgk=="fullscreen_list"))
{
lZqwx(kpvpM)
loadFullscreen("fullscreen",ivUmM)
}
else
if(OQdgk=="fullscreen")
{
return
}
}
function closeFullscreen()
{
var qkHoA=waJSQuery(document).data("origin_fullscreen_gallery") 
qkHoA.data("diaporama",false)
var kDgbq=waJSQuery(".wa-fullscreen-contenair");
kDgbq.fadeOut(200,function(){
var kpvpM=waJSQuery(document).data("origin_fullscreen_gallery")
kDgbq.empty()
kpvpM.focus()
})
waSetVisibilityMainPageContenair(true) 

}
function kWEnb(kpvpM)
{
var OQdgk=kpvpM.data("mode")
var RxmUM=HKWMJ(kpvpM).data("type_gallery")
if((OQdgk=="normal")&&(RxmUM==1)) return false;
return true;
}
function loadFullscreen(Ywamk,JhvkZ)
{
var qkHoA=waJSQuery(document).data("origin_fullscreen_gallery")
if(JhvkZ==undefined)
{
JhvkZ=qkHoA.data("current_image");
}
else
{
qkHoA.data("current_image",JhvkZ);
}

var umkiC=getDocumentSize().width()
var rFcVE=getDocumentSize().height()
waSetVisibilityMainPageContenair(false) 
var GROls=extractParamInfo(qkHoA,"config_key")
var OjEXY=""
OjEXY+="<div class='wa-dialog-container-bg' style='position:absolute;left:0px;top:0px;;' ></div>"
OjEXY+="<div style=\"";
OjEXY+="position:absolute;width:100%;height:100%;"
OjEXY+="overflow:hidden;";
OjEXY+="\" class=\"wa-gallery  param[config_key("+GROls+")]\">";
OjEXY+="<div class=\"wa-gallery-scroll-pane\"></div>";
OjEXY+="<div class=\"wa-gallery-navigation\"></div>";
OjEXY+="</div>";
var kDgbq=waJSQuery(".wa-fullscreen-contenair");
kDgbq.empty()
kDgbq.html(OjEXY)
kDgbq.css("width",umkiC)
kDgbq.css("height",rFcVE)
kDgbq.show()
var pHUkE=kDgbq.find(".wa-dialog-container-bg");
var msGCF=new RGBColor(CONST_WA_GLOBAL_SETTINGS.overlayColor)
pHUkE.css({"backgroundColor":msGCF.toHexaOpaqueColor(),"opacity":msGCF.a})
pHUkE.css({width:umkiC,height:rFcVE})
var kpvpM=kDgbq.find(".wa-gallery")
kpvpM.click(function(){
closeFullscreen()
return false
});
kDgbq.css("cursor","pointer") 
var fuISj=200;
var gjuIE=5;
var FtHcE=false;
var OKFMo=0;
var qcncQ=0;
var WZaUR=0;
if(Ywamk=="fullscreen_list")
{
OKFMo=50
qcncQ=30
if(xAvoa(kpvpM)>1)
{
WZaUR=40
}
}
var mlirl=umkiC-2*OKFMo
var iMtFB=rFcVE-(WZaUR+qcncQ)
if(Ywamk=="fullscreen_list")
{
var lkcag=qkHoA.data("datas").fullscreen_list_config
var HjTAp=Math.min(mlirl,iMtFB)
fuISj=Math.min(lkcag.image_size,HjTAp*0.8)
var mkscA=10 
gjuIE=(mkscA/2)*fuISj/100;
FtHcE=lkcag.has_shadow;
}
var EXdDa=waJSQuery(window).scrollLeft();
var oBxTl=waJSQuery(window).scrollTop();
var bLrHU=Math.floor((mlirl)/(fuISj+2*gjuIE));
var VwddP=Math.floor((iMtFB)/(fuISj+2*gjuIE));
var BegCq=oBxTl+qcncQ+(iMtFB-VwddP*(fuISj+2*gjuIE))/2;
var OQIMN=EXdDa+(umkiC-(bLrHU*(fuISj+2*gjuIE)))/2;
var OQdgk=kpvpM.data("mode")
if(Ywamk=="fullscreen")
{
fuISj=800;
gjuIE=0;
bLrHU=1;
VwddP=1;
BegCq=0;
OQIMN=0;
}
kpvpM.data("mode",Ywamk)
var EjnJm={
"rows":VwddP,"cols":bLrHU,"image_size":fuISj,"image_spacing":gjuIE,"nb_images_per_page":bLrHU*VwddP,"margin_left":OQIMN,"margin_top":BegCq,"default_selected_image":JhvkZ,"has_shadow":FtHcE
}
SPfgC(kpvpM,EjnJm)
return kpvpM
}
function YCewR(kpvpM)
{
var ZrZEF=HKWMJ(kpvpM).data("3rdparty_datas")
if(ZrZEF)
{
return rdQZh(kpvpM,ZrZEF).photo.length
}
return HKWMJ(kpvpM).data("datas").images.length
}
function wAqli(kpvpM)
{
var SVXYD=nXMHd(kpvpM,0)
var WiDBJ=waJSQuery(">.wa-gallery-image-contenair",SVXYD);
return WiDBJ.length;
}
function xAvoa(kpvpM)
{
var AbwYZ=YCewR(kpvpM);
return Math.ceil(AbwYZ/wAqli(kpvpM));
}
function CsICf(kpvpM)
{
var ivUmM=kpvpM.data("page")
return(ivUmM==undefined)?0:ivUmM;
}
function nXMHd(kpvpM,ivUmM)
{
var tdnxv=kpvpM.find(".wa-gallery-page")
var KFNdN=null;
tdnxv.each(function(i)
{
if(i==ivUmM)
{
KFNdN=waJSQuery(this)
return false;
}
});
return KFNdN;
}
function CXUII(kpvpM)
{
var ivUmM=kpvpM.data("first-layout")
return(ivUmM==undefined)?0:ivUmM;
}
function LHqbJ(kpvpM)
{
var ivUmM=kpvpM.data("isBusy")
return(ivUmM==undefined)?false:ivUmM;
}
function MKJqh(kpvpM,b)
{
kpvpM.data("isBusy",b)
}
function eKEQf(kpvpM)
{
var vpFmW=CsICf(kpvpM)
KBTRN(kpvpM,vpFmW-1)
}
function ZAaGm(kpvpM)
{
var vpFmW=CsICf(kpvpM)
KBTRN(kpvpM,vpFmW+1)
}
function HKWMJ(kpvpM)
{
if(kpvpM.data("mode")!="normal") return waJSQuery(document).data("origin_fullscreen_gallery")
return kpvpM
}
function ICZxk()
{
var kpvpM=waJSQuery(".wa-fullscreen-contenair").find(".wa-gallery")
if(kpvpM&&(kpvpM.length>0))
{
return kpvpM
}
return null;
}
function SIhLa(kpvpM)
{
return kpvpM.data("diaporama")==true 
}
function huoPV(kpvpM)
{
var rDerp=HKWMJ(kpvpM).data("datas").global_config.diaporama_time*1000;
kpvpM.data("diaporama",true)
wa_timeout(function(){bQpcO(kpvpM)},rDerp)
}
function bQpcO(kpvpM)
{
if(SIhLa(kpvpM)==false)
{
return;
}
var UgZRa=null;
if(UgZRa==null) UgZRa=kpvpM;
if(CsICf(UgZRa)>=xAvoa(UgZRa)-1)
{

UgZRa.data("page",-1)
}
if(kpvpM.data("datas").global_config.random_diaporama)
{
var ivUmM=Math.round((YCewR(kpvpM)-1)*Math.random());
UgZRa.data("page",ivUmM-1)
}
ZAaGm(UgZRa)
huoPV(kpvpM);
}
function brFIl(kpvpM)
{

var wDhKX=CsICf(kpvpM)*wAqli(kpvpM)
var nHkwS=loadFullscreen("fullscreen",wDhKX)
huoPV(nHkwS)
}
