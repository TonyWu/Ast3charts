var CONST_WA_GLOBAL_SETTINGS={"b":"0","currency_code":"USD","currency_decimal_symbol":".","currency_mnemonic":"$","currency_info":"1kod8gkpdf070v","list_type_payment":[],"custom_script_labels":['','',''],"list_country":[],"list_favorite_country":['FR','US','CA'],"shipping_type":0,"use_native_paypal_cart":true,list_promo_codes:false,shipping_intervals:[],"tva_type":0,list_tva_by_country_code:[],link_sale_condition:{ "js" : "", "open" : -1, "type" : 0, "url" : "" },"weight_type":0,"email_paypal_account":"","seller_address":"","bank_account_informations":"","default_selected_country":"","list_form_fields":['firstname','lastname','address','email'],"list_mandatory_form_fields":['firstname','lastname','address','email'],"prefix_order_number":"wa-","send_copy_email_to_buyer":false,"order_can_be_pick_up_in_store":false,"theme":{"buttons":{"bg":"#4ab1d3","border":"#333333","text":"#ffffff","bg_over":"#4ab1d3","border_over":"#333333","text_over":"#ffffff"}},"overlayColor":"rgba(0,0,0,0.5)","blogs_settings":{"has_email":true}}
waJSQuery(document).ready(function() {
var _boxes = waJSQuery(".fancybox");
if (_boxes.length>0)
_boxes.fancybox({
"transitionIn":"elastic",
"transitionOut":"elastic",
"titlePosition":"inside",
"cyclic":0,
"overlayShow":true,
"overlayOpacity":0.501961,
"overlayColor":"#000000"})
})
