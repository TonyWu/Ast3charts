<!--

waJSQuery(window).load(function(){
initializeAllWA_form();
});
function iALmR(GgoaN)
{
var IpPNw=GgoaN.find('select,input,textarea');
IpPNw.each(function(i)
{
var Awtjf=IpPNw[ i ];
if(Awtjf.type=='checkbox'){
Awtjf.checked=false;
}
else if(Awtjf.type.startsWith('select')){
var wSBmM=Awtjf.options.selectedIndex;
if(wSBmM!=-1){
Awtjf.options.selectedIndex=-1;
Awtjf.options[ wSBmM ].selected=false;
}
}
else{
Awtjf.value='';
}
});
}
function bVsNg(GgoaN)
{
var IpPNw=GgoaN.find('select,input[type!=checkbox],textarea,div[class*=divCheckBox]')
var wOMej=extractParamInfo(GgoaN,"url")
var eVQjf=extractParamInfo(GgoaN,"email_valid")
var BGqRk=false;
var backgroundError="#f8c7c7";
IpPNw.each(function(i)
{
var Awtjf=IpPNw[ i ];
var WDlTd=waJSQuery(this);
var SHirq=parseInt(extractParamInfo(WDlTd,"max"))
var phcZl=extractParamInfo(WDlTd,"mandatory")
var COvGq=extractParamInfo(WDlTd,"email")
if(Awtjf.tagName.toLowerCase()=='div'){
if(phcZl=="1")
{
var checkedCount=WDlTd.find("input[type=checkbox]:checked").size();
if(checkedCount==0)
{
WDlTd.css("backgroundColor",backgroundError);
WDlTd.focus();
BGqRk=true;
return false;
}
}
}
else
{
WDlTd.val(waJSQuery.trim(WDlTd.val())) 
var TggGi=WDlTd.val();
var aZSME=TggGi!=undefined?TggGi.length:0;
if(SHirq>0)
{
if(aZSME>SHirq)
{
WDlTd.css("backgroundColor",backgroundError)
WDlTd.focus()
BGqRk=true;
return false;
}
}
if(phcZl=="1")
{
var hasValidLength=aZSME>0;
if(!hasValidLength)
{
WDlTd.css("backgroundColor",backgroundError)
WDlTd.focus()
BGqRk=true;
return false;
}
}
if(COvGq=="1")
{
if((aZSME>0)&&(isValidEmailAddress(TggGi)==false))
{
WDlTd.css("backgroundColor",backgroundError)
WDlTd.focus()
BGqRk=true;
return false;
}
}
}
});
if(BGqRk) return false;
if(document.webaca_is_preview)
{
WA_Dialog.alert(Translator.tr("Operation not allowed in preview mode"));return false;
}
WA_Dialog.progress();
var ilOTa="";
IpPNw.each(function(i)
{
var VuVWl=waJSQuery(this)
var Awtjf=IpPNw[ i ];
if(ilOTa.length>0)
{
ilOTa+=","
}
var dkKqS=VuVWl.attr("name");
var TggGi='';
if(Awtjf.tagName.toLowerCase()=='div'){
var SiDmf=VuVWl.find("input[type=checkbox]:checked");
SiDmf.each(function(j)
{
var UKMFf=SiDmf[ j ];
if(TggGi.length>0)
{
TggGi+=', '
}
TggGi+=UKMFf.value;
});
dkKqS=VuVWl.find("input[type=checkbox]")[ 0 ].name;
}
else
{
TggGi=VuVWl.val();
}
TggGi=TggGi.replace(/\n/gi,"\\n")
TggGi=TggGi.replace(/"/gi,"\\\"")
ilOTa+="\""+dkKqS+"\":\""+TggGi+"\"";
});

var DcOjp=waJSQuery.parseJSON("{"+ilOTa+"}");
waJSQuery.post(wOMej,DcOjp,function(data){
if(data.indexOf("<?php")>-1)
{
WA_Dialog.alert(Translator.tr("Error:No php on server"));
}
else
{
var IYroG=waParseCleanStringJSON(data);
if(IYroG==null)
{
WA_Dialog.alert(Translator.tr("Error:Malformed response !"));
}
else
{
if(IYroG.success==true)
{
iALmR(GgoaN)
var FbjQS=Translator.tr("Success:Mail sended");
if(IYroG.error.length>0)
{
FbjQS+="<br>"
FbjQS+="<br>"
FbjQS+=IYroG.error
}
WA_Dialog.alert(FbjQS);
}
else
{
WA_Dialog.alert(IYroG.error);
}
}
}
}).success(function(){
}).error(function(){WA_Dialog.alert("*error send mail!");}).complete(function(){
});
return true;
};
function initializeAllWA_form()
{
waJSQuery(".wa-form").each(function(i)
{
var GgoaN=waJSQuery(this)
var IpPNw=GgoaN.find('select,input[type!=checkbox],textarea,div[class*=divCheckBox]')
var wOMej=extractParamInfo(GgoaN,"url")
var eVQjf=extractParamInfo(GgoaN,"email_valid") 
IpPNw.each(function(i)
{
var WDlTd=waJSQuery(this);
var oldBg=WDlTd.attr("oldBackgroundColor");
if(oldBg==undefined){
oldBg=WDlTd.css("backgroundColor");
WDlTd.attr("oldBackgroundColor",oldBg);
}
WDlTd.keypress(function(e){
var WDlTd=waJSQuery(this)
if(e.which==13)
{
if(WDlTd.prop('tagName')=="TEXTAREA")
{
return true;
}
return false;
}
return true;
});
var SHirq=parseInt(extractParamInfo(WDlTd,"max"))
if(SHirq>0)
{
WDlTd.keyup(function(e){
var VuVWl=waJSQuery(this)
var SHirq=parseInt(extractParamInfo(VuVWl,"max"))
var TggGi=WDlTd.val()
var aZSME=TggGi!=undefined?TggGi.length:0;
if(aZSME>SHirq)
{
VuVWl.val(TggGi.substring(0,SHirq))
}
});
}
WDlTd.change(function()
{
var oldBg=WDlTd.attr("oldBackgroundColor");
WDlTd.css("backgroundColor",oldBg)
});
});
});
waJSQuery(".wa-form-button-reset").each(function(i)
{
var lCKPx=waJSQuery(this) 
var iOINi=lCKPx;
iOINi.css("cursor","pointer")
lCKPx.css("cursor","pointer")
iOINi.click(function()
{
var GgoaN=waJSQuery(this).parents("form") 
iALmR(GgoaN)
return false;
});
});
waJSQuery(".wa-form-button-submit").each(function(i)
{
var lCKPx=waJSQuery(this)
var iOINi=lCKPx;
iOINi.css("cursor","pointer")
lCKPx.css("cursor","pointer") 
iOINi.click(function()
{
var GgoaN=waJSQuery(this).parents("form")
bVsNg(GgoaN)
return false;
});
});
}

-->
