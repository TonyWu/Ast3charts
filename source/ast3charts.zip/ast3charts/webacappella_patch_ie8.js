function ZYQUW()
{
waJSQuery(".wa-comp").each(function(i)
{
var kpvpM=waJSQuery(this)
var LPTwk=kpvpM.attr("style")
var RnlWZ=kpvpM.data("ms-opacity")
var QqDDx=waExtractCssStyle(LPTwk,"-moz-transform")
if(QqDDx.length>0)
{
var ivUmM=QqDDx.indexOf("(")
if(ivUmM>-1)
{
QqDDx=QqDDx.substring(ivUmM+1)
ivUmM=QqDDx.indexOf("deg")
if(ivUmM>-1)
{
QqDDx=QqDDx.substring(0,ivUmM)
}
}
QqDDx=parseInt(QqDDx)
var HAScK=0;
var tFqeC=0;
var DaMut=waExtractCssStyle(LPTwk,"-ms-transform-offset") 
var sVgUb=DaMut.split(" ")
if(sVgUb.length==2)
{
HAScK=parseInt(sVgUb[0])
tFqeC=parseInt(sVgUb[1])
}
var rad_rot=QqDDx*2*Math.PI/360;
var costheta=Math.cos(rad_rot);
var sintheta=Math.sin(rad_rot);
var M11=costheta;
var M12=-sintheta;
var M21=sintheta;
var M22=costheta;
kpvpM.css({"left":kpvpM.position().left+HAScK,"top":kpvpM.position().top+tFqeC})
var aHeXq="progid:DXImageTransform.Microsoft.Matrix(M11="+M11+",M12="+M12+",M21="+M21+",M22="+M22+",SizingMethod='auto expand') ";
if((isNaN(RnlWZ)==false)&&(RnlWZ>=0)&&(RnlWZ<1))
{
aHeXq+="Alpha(opacity="+Math.floor(RnlWZ*100)+")"
}
kpvpM.css("filter",aHeXq) 
}
});
}
function DUamT(kpvpM,Muipm,LjdHk)
{
if(LjdHk==undefined)LjdHk=""
if(Muipm&&(Muipm!="#")&&(Muipm!="javascript:void(0)")&&(Muipm.indexOf("javascript:")==-1))
{
kpvpM.css("cursor","pointer")
kpvpM.data("href_ie8",Muipm)
kpvpM.data("target_ie8",LjdHk)
kpvpM.attr("href","javascript:void(0)")
kpvpM.attr("target","")
kpvpM.click(function(){
var kpvpM=waJSQuery(this)
var Muipm=kpvpM.data("href_ie8")
var LjdHk=kpvpM.data("target_ie8")
return waOnClick(Muipm,{"targ":LjdHk})
});
}
}
function rGuMa()
{

waJSQuery(".wa-comp").each(function(i)
{
var kpvpM=waJSQuery(this)
var LPTwk=kpvpM.attr("style")
var RnlWZ=waExtractCssStyle(LPTwk,"opacity")
var RnlWZ=parseFloat(RnlWZ)
if((isNaN(RnlWZ)==false)&&(RnlWZ>=0)&&(RnlWZ<1))
{
kpvpM.css("filter","Alpha(opacity="+Math.floor(RnlWZ*100)+")")
kpvpM.data("ms-opacity",RnlWZ)
}
});
waJSQuery(".wa-button").each(function(i)
{
var kpvpM=waJSQuery(this)
var WkRmK=kpvpM.find(".wa-but-txt")
var korDG=WkRmK.parent("div")
korDG.css("width",WkRmK.width())
if(kpvpM.height()<korDG.height())
{
var klWnW=(kpvpM.width()-korDG.width())/2
var IOdDJ=(kpvpM.height()-korDG.height())/2 
korDG.css({"position":"absolute","left":klWnW,"top":IOdDJ})
}

});

{
waJSQuery(".wa-dynmenu").each(function(i)
{
var kpvpM=waJSQuery(this)
var EjnJm=waGetJsonCss(kpvpM,"config");
if(EjnJm.vertical)
{
var RirVN=kpvpM.find("TD")
RirVN.each(function(i)
{
var ekFQY=waJSQuery(this)
var fWgAT=ekFQY.height()
fWgAT=fWgAT-2
ekFQY.css({"line-height":fWgAT+"px","height":fWgAT+"px"})
})
}
});
}
ZYQUW()
}
function waPatchIE()
{
if(isMSIE()==false)
{
return;
}
if(isMSIE_lower_than_ie9())
{
rGuMa()
}

}
