<!--
 
waJSQuery(function(){
waJSQuery.fn.extend({
disableSelection:function(){
this.each(function(){
this.onselectstart=function(){return false;};
this.unselectable="on";
waJSQuery(this).css('-moz-user-select','none');
waJSQuery(this).css('-webkit-user-select','none');
});
}
});
waJSQuery.fn.extend({everyTime:function(interval,label,fn,times,belay){return this.each(function(){waJSQuery.timer.add(this,interval,label,fn,times,belay);});},oneTime:function(interval,label,fn){return this.each(function(){waJSQuery.timer.add(this,interval,label,fn,1);});},stopTime:function(label,fn){return this.each(function(){waJSQuery.timer.remove(this,label,fn);});}});waJSQuery.extend({timer:{guid:1,global:{},regex:/^([0-9]+)\s*(.*s)?$/,powers:{
'ms':1,'cs':10,'ds':100,'s':1000,'das':10000,'hs':100000,'ks':1000000},timeParse:function(value){if(value==undefined||value==null) return null;var result=this.regex.exec(waJSQuery.trim(value.toString()));if(result[2]){var num=parseInt(result[1],10);var mult=this.powers[result[2]]||1;return num*mult;}else{return value;}},add:function(element,interval,label,fn,times,belay){var counter=0;if(waJSQuery.isFunction(label)){if(!times) times=fn;fn=label;label=interval;}interval=waJSQuery.timer.timeParse(interval);if(typeof interval!='number'||isNaN(interval)||interval<=0) return;if(times&&times.constructor!=Number){belay=!!times;times=0;}times=times||0;belay=belay||false;if(!element.$timers) element.$timers={};if(!element.$timers[label]) element.$timers[label]={};fn.$timerID=fn.$timerID||this.guid++;var handler=function(){if(belay&&this.inProgress) return;this.inProgress=true;if((++counter>times&&times!==0)||fn.call(element,counter)===false) waJSQuery.timer.remove(element,label,fn);this.inProgress=false;};handler.$timerID=fn.$timerID;if(!element.$timers[label][fn.$timerID]) element.$timers[label][fn.$timerID]=window.setInterval(handler,interval);if(!this.global[label]) this.global[label]=[];this.global[label].push(element);},remove:function(element,label,fn){var timers=element.$timers,ret;if(timers){if(!label){for(label in timers) this.remove(element,label,fn);}else if(timers[label]){if(fn){if(fn.$timerID){window.clearInterval(timers[label][fn.$timerID]);delete timers[label][fn.$timerID];}}else{for(var fn in timers[label]){window.clearInterval(timers[label][fn]);delete timers[label][fn];}}for(ret in timers[label]) break;if(!ret){ret=null;delete timers[label];}}for(ret in timers) break;if(!ret) element.$timers=null;}}}});if(waJSQuery.browser.msie) waJSQuery(window).one("unload",function(){var global=waJSQuery.timer.global;for(var label in global){var els=global[label],i=els.length;while(--i) waJSQuery.timer.remove(els[i],label);}});
if(document.internalPreview!=true)
{
waJSQuery(".wa-market-link").each(function()
{
var iOINi=waJSQuery(this);
iOINi.css("cursor","pointer") 
iOINi.click(function()
{
javascript:WA_showMarketCart() 
});
});
}
});


function waParseCleanStringJSON(s)
{
var XLiCL="{"
var qICSB="}"
var AqWpE=""
var c;
for(var i=0;i<s.length;i++)
{
c=s.charAt(i)
if(c=="\"")
{
do
{
i++;
c=s.charAt(i)
}
while(c!="\"")
}
if(c==XLiCL)
{
var GRfvF=0;
var OwSQq=true;
var husMc=false;
do
{
OwSQq=true;
i++;
c=s.charAt(i)
if((husMc==false)&&(c=="\""))
{
husMc=true;
}
else
if((husMc==true)&&(c=="\""))
{
husMc=false;
}
if(husMc==false)
{
if(c==XLiCL)
{
GRfvF++;
}
if((c!=qICSB)||(GRfvF!=0))
{
AqWpE+=c;
}
if(GRfvF>0)
if(c==qICSB)
{
GRfvF--;
OwSQq=false
}
}
else
{
AqWpE+=c;
}
}
while((OwSQq==false)||(c!=qICSB)||(GRfvF!=0))
break;
}
}
AqWpE=XLiCL+AqWpE+qICSB 
try{
return waJSQuery.parseJSON(AqWpE);
}
catch(e){
}
return null;
}
function waLoadGoogleFonts()
{
var wf=document.createElement('script');
wf.src=('https:'==document.location.protocol?'https':'http')+'://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
wf.type='text/javascript';
wf.async='true';
var s=document.getElementsByTagName('script')[0];
s.parentNode.insertBefore(wf,s);
}
var BrowserDetect={
init:function(){
this.browser=this.searchString(this.dataBrowser)||"An unknown browser";
this.version=this.searchVersion(navigator.userAgent)||this.searchVersion(navigator.appVersion)||"an unknown version";
this.OS=this.searchString(this.dataOS)||"an unknown OS";
},searchString:function(data){
for(var i=0;i<data.length;i++){
var dataString=data[i].string;
var dataProp=data[i].prop;
this.versionSearchString=data[i].versionSearch||data[i].identity;
if(dataString){
if(dataString.indexOf(data[i].subString)!=-1)
return data[i].identity;
}
else if(dataProp)
return data[i].identity;
}
},searchVersion:function(dataString){
var index=dataString.indexOf(this.versionSearchString);
if(index==-1) return;
return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
},dataBrowser:[
{
string:navigator.userAgent,subString:"Chrome",identity:"Chrome"
},{string:navigator.userAgent,subString:"OmniWeb",versionSearch:"OmniWeb/",identity:"OmniWeb"
},{
string:navigator.vendor,subString:"Apple",identity:"Safari",versionSearch:"Version"
},{
prop:window.opera,identity:"Opera",versionSearch:"Version"
},{
string:navigator.vendor,subString:"iCab",identity:"iCab"
},{
string:navigator.vendor,subString:"KDE",identity:"Konqueror"
},{
string:navigator.userAgent,subString:"Firefox",identity:"Firefox"
},{
string:navigator.vendor,subString:"Camino",identity:"Camino"
},{
string:navigator.userAgent,subString:"Netscape",identity:"Netscape"
},{
string:navigator.userAgent,subString:"MSIE",identity:"Explorer",versionSearch:"MSIE"
},{
string:navigator.userAgent,subString:"Gecko",identity:"Mozilla",versionSearch:"rv"
},{
string:navigator.userAgent,subString:"Mozilla",identity:"Netscape",versionSearch:"Mozilla"
}
],dataOS:[
{
string:navigator.platform,subString:"Win",identity:"Windows"
},{
string:navigator.platform,subString:"Mac",identity:"Mac"
},{
string:navigator.userAgent,subString:"iPhone",identity:"iPhone/iPod"
},{
string:navigator.platform,subString:"Linux",identity:"Linux"
}
]
};
BrowserDetect.init();
function RGBColor(KwhGZ)
{
this.ok=false;this.a=1.0;
if(KwhGZ.charAt(0)=='#'){KwhGZ=KwhGZ.substr(1);}
KwhGZ=KwhGZ.replace(/ /g,'');
KwhGZ=KwhGZ.toLowerCase();
var MbiQJ=[
{re:/^rgba\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3}),\s*(\d{1,2}\.*\d{0,2})\)$/,_process:function(bits){return [ parseInt(bits[1]),parseInt(bits[2]),parseInt(bits[3]),parseFloat(""+bits[4]) ];}},{re:/^rgb\((\d{1,3}),\s*(\d{1,3}),\s*(\d{1,3})\)$/,_process:function(bits){return [ parseInt(bits[1]),parseInt(bits[2]),parseInt(bits[3])];}},{re:/^(\w{2})(\w{2})(\w{2})(\w{2})$/,_process:function(bits){return [ parseInt(bits[1],16),parseInt(bits[2],16),parseInt(bits[3],16),Math.round(parseInt(bits[4],16)*100/255)/100 ];}},{re:/^(\w{2})(\w{2})(\w{2})$/,_process:function(bits){return [ parseInt(bits[1],16),parseInt(bits[2],16),parseInt(bits[3],16) ];}}
];
for(var i=0;i<MbiQJ.length;i++){
var eOpsf=MbiQJ[i].re;
var AVDJE=MbiQJ[i]._process;
var PUxWr=eOpsf.exec(KwhGZ);
if(PUxWr){
var tMuUu=AVDJE(PUxWr);
this.r=tMuUu[0];this.g=tMuUu[1];this.b=tMuUu[2];this.a=tMuUu[3];
this.ok=true;
}
}
this.r=(this.r<0||isNaN(this.r))?0:((this.r>255)?255:this.r);
this.g=(this.g<0||isNaN(this.g))?0:((this.g>255)?255:this.g);
this.b=(this.b<0||isNaN(this.b))?0:((this.b>255)?255:this.b);
this.a=(this.a>1||isNaN(this.a))?1:((this.a<0)?0:this.a);
this.toRGB=function()
{
if(this.a==1)return 'rgb('+this.r+', '+this.g+', '+this.b+')';
return 'rgba('+this.r+', '+this.g+', '+this.b+','+this.a+')';
}
this.toRGB_opaque=function()
{
return 'rgb('+this.r+', '+this.g+', '+this.b+')';
}
this.wLDiA=function(qqLBX)
{
if(qqLBX.length==1)qqLBX="0"+qqLBX
return qqLBX
}
this.toHexaOpaqueColor=function()
{
return  "#"+this.wLDiA(this.r.toString(16))+this.wLDiA(this.g.toString(16))+this.wLDiA(this.b.toString(16));
}
}
function compliantColor(CYQGH)
{
if(isMSIE_lower_than_ie9())
{
if(CYQGH=="") return "";
if(CYQGH=="transparent") return "";
var gWxxF=new RGBColor(CYQGH)
if(gWxxF.a==0) return ""
return gWxxF.toHexaOpaqueColor();
}
return CYQGH;
}
function isProbablyRobot()
{
return BrowserDetect.browser.length==0
}
function isMSIE()
{
return BrowserDetect.browser=="Explorer"
}
function isFirefox()
{
return BrowserDetect.browser=="Firefox" 
}
function isChrome()
{
return BrowserDetect.browser=="Chrome"
}
function isWindowsOS()
{
if(BrowserDetect.OS.match(/windows/i)) return true;
return false;
}
function isMSIE8()
{
if((BrowserDetect.browser=="Explorer")&&(BrowserDetect.version==8))
{
return true;
}
return false;
}
function isMSIE_lower_than_ie9()
{
if(isMSIE())
{
if(document.documentMode)
{
if(document.documentMode>=9)
{
return false;
}
}
return true;
}
return false;
}
function isMSIE_higher_than_ie8()
{
if(isMSIE())
{
if(document.documentMode)
{
if(document.documentMode>=9)
{
return true;
}
}
return false;
}
return false;
}
function isWebKit()
{
if(navigator.userAgent.match(/webkit/i)) return true;
return false;
}
function isAndroidMobile()
{
if(navigator.userAgent.match(/android/i)) return true;
return false;
}
function isMobileBrowser()
{
return isAppleMobile()||isAndroidMobile();
}
function isChrome()
{
if(navigator.userAgent.match(/Chrome/i))
return true;
return false;
}
function isAppleMobile()
{
return isIPhone()||isIPad()
}
function isIPad()
{
if(navigator.userAgent.match(/iPad/i))
return true;
return false;
}
function isIPhone()
{
if(navigator.userAgent.match(/iPhone/i)||navigator.userAgent.match(/iPod/i))
return true;
return false;
}
function extractNum(st)
{
var len=st.length
if((len>0)&&(st.substring(len-2,len)=="px"))
{
return wa_evaluate(st.substring(0,len-2))
}
return 0;
}
function waJSONLinkToHref(iOINi)
{
var qqLBX=""
var wOMej=iOINi.url
var WWUes=Translator.m_lang_for_filename
if(WWUes.length>0)WWUes="_"+WWUes
wOMej=wOMej.replace(/@lng@/g,WWUes)
var HPLNw=iOINi.js
if(HPLNw==undefined)HPLNw=""
qqLBX+="href=\""+wOMej+"\" "
if(iOINi.open==1)
{
qqLBX+="target="
qqLBX+="_blank "
}
if(HPLNw.length>0)
{
qqLBX+="onclick=waLaunchFunction(function(){"+HPLNw+"}) "
}
return qqLBX;
}
function waJSONLinkToOnClick(iOINi)
{
var qqLBX=""
var wOMej=iOINi.url
var WWUes=Translator.m_lang_for_filename
if(WWUes.length>0)WWUes="_"+WWUes
wOMej=wOMej.replace(/@lng@/g,WWUes)
var LjdHk="";
if(iOINi.open==1)
{
LjdHk="_blank"
}
var HPLNw=iOINi.js
if(HPLNw==undefined)HPLNw=""
HPLNw=HPLNw.replace(/\"/g,"&quot;")
qqLBX+="onclick=\"waOnClick('"+wOMej+"',{'targ':'"+LjdHk+"'";
if(HPLNw.length>0)
{
qqLBX+=",'js':function(){"+HPLNw+"}"
}
qqLBX+="});return false;\" "
return qqLBX;
}
function waLaunchFunction(GEVSL)
{
GEVSL()
}
function waOnClick(wOMej,tpCSx)
{
if(tpCSx.js!=undefined)
{
try
{
tpCSx.js()
}
catch(e)
{
alert('ERROR: javascript link '+tpCSx.js)
}
}
if((wOMej==undefined)||(wOMej.length==0)) return;
var LjdHk=tpCSx.targ;
if(LjdHk&&LjdHk.length>0)
{
if((LjdHk.length>0)&&(LjdHk!="_blank"))
{
window.frames[LjdHk].location.href=(wOMej)
}
else
{
window.open(wOMej,LjdHk)
}
}
else
{
window.location.href=(wOMej)
}
return false;
}


function waActivateDynamicLoader(isJEs,Freqo)
{
var ecfIV=isJEs.find(".wa-dyn-loader")
if(ecfIV.data('timer_animation_initialized')==true)
{
return;
}
ecfIV.data('timer_animation_initialized',true) 
if(Freqo)
{
ecfIV.css({"width":isJEs.width(),"height":isJEs.height()})
}
var aeDpD=65
var CFFVk=500;
var liQoG=ecfIV.children("img")
ecfIV.everyTime(aeDpD,function(i)
{
var rfNJn=waJSQuery(this).data("anim_delay_img")
if(rfNJn==undefined)rfNJn=aeDpD;
if(rfNJn>=CFFVk)
{
liQoG.show()
}
var egNgN=ecfIV.data("anim_frm")
if(egNgN==undefined)egNgN=0;
var rRbrh=40
var hbfRq=0;
var XuBVZ=egNgN*rRbrh
var vWEHN=hbfRq+rRbrh;
var TJStU=XuBVZ+rRbrh;;
var xQKSH=(waJSQuery(this).width()-rRbrh)/2
var QijDi=(waJSQuery(this).height()-rRbrh)/2
liQoG.css({"left":xQKSH,"top":-XuBVZ+QijDi})
liQoG.css({"clip":"rect("+XuBVZ+"px,"+vWEHN+"px,"+TJStU+"px,"+hbfRq+"px)"})
egNgN=(egNgN+1)%12
waJSQuery(this).data("anim_frm",egNgN)
rfNJn+=aeDpD
waJSQuery(this).data("anim_delay_img",rfNJn)
});
}
function htmlDynamicLoader(AvlLm,aLMTO,QINwj)
{
var qqLBX=""
qqLBX+="<div class='wa-dyn-loader' style=\"";
if(AvlLm)
{
qqLBX+="position:absolute;left:0px;top:0px;"
}
else
{
qqLBX+="position:relative;left:0px;top:0px;"
}
qqLBX+="width:"+aLMTO+"px;height:"+QINwj+"px;"
qqLBX+="overflow:hidden;" 
var n=0
var rRbrh=40
var hbfRq=0;
var XuBVZ=n*rRbrh
var vWEHN=hbfRq+rRbrh;
var TJStU=XuBVZ+rRbrh;;
qqLBX+=";\">"
qqLBX+="<img style=\"position:absolute;border:none;left:0px;top:0px;";
qqLBX+="display:none;"
qqLBX+="clip:rect("+XuBVZ+"px,"+vWEHN+"px,"+TJStU+"px,"+hbfRq+"px);"
qqLBX+="\" ";
qqLBX+="src=\"wa_loading.png\" />"
qqLBX+="</div>"
return qqLBX;
}
function Size(lx,ly)
{
this.aLMTO=lx;this.QINwj=ly;
this.width=function(){return this.aLMTO}
this.height=function(){return this.QINwj}
this.clone=function(){return new Size(this.aLMTO,this.QINwj)}
this.greaterThan=function(qqLBX){if(qqLBX==undefined) return null;return(this.aLMTO>qqLBX.aLMTO)&&(this.QINwj>qqLBX.QINwj)}
this.toString=function()
{
return this.width()+"x"+this.height()
}
this.scale=function(SHirq,Npwsb)
{
if(!Npwsb)Npwsb=false
var rRbrh=this;
var ShviK=rRbrh.width()
var iDfCg=rRbrh.height()
var p1=ShviK*SHirq.height();
var p2=SHirq.width()*iDfCg;
var r1=ShviK/iDfCg;
var r2=iDfCg/ShviK;
var newSize1=new Size(SHirq.height()*r1,SHirq.height());
var newSize2=new Size(SHirq.width(),SHirq.width()*r2);
if(p2>p1)
{
if((Npwsb==true)||((newSize1.width()<=rRbrh.width())&&(newSize1.height()<=rRbrh.height())))
{
rRbrh.aLMTO=Math.round(newSize1.width());
rRbrh.QINwj=Math.round(newSize1.height());
}
}
else
{
if((Npwsb==true)||((newSize2.width()<=rRbrh.width())&&(newSize2.height()<=rRbrh.height())))
{
rRbrh.aLMTO=Math.round(newSize2.width());
rRbrh.QINwj=Math.round(newSize2.height());
}
}
this.aLMTO=rRbrh.width();
this.QINwj=rRbrh.height();
return true;
}
this.scaleByExpanding=function(SHirq)
{
var rRbrh=this;
var ShviK=rRbrh.width()
var iDfCg=rRbrh.height()
var p1=ShviK*SHirq.height();
var p2=SHirq.width()*iDfCg;
var r1=ShviK/iDfCg;
var r2=iDfCg/ShviK;
var newSize1=new Size(SHirq.height()*r1,SHirq.height());
var newSize2=new Size(SHirq.width(),SHirq.width()*r2);
if(p2<p1)
{
if((newSize1.width()<=rRbrh.width())&&(newSize1.height()<=rRbrh.height()))
{
rRbrh.aLMTO=Math.round(newSize1.width());
rRbrh.QINwj=Math.round(newSize1.height());
}
}
else
{
if((newSize2.width()<=rRbrh.width())&&(newSize2.height()<=rRbrh.height()))
{
rRbrh.aLMTO=Math.round(newSize2.width());
rRbrh.QINwj=Math.round(newSize2.height());
}
}
this.aLMTO=rRbrh.width();
this.QINwj=rRbrh.height();
return true;
}
}
function Point(p_x,p_y){this.x=p_x;this.y=p_y;
this.translate=function(QJeup,SITJT){this.x+=QJeup;this.y+=SITJT;}
this.clone=function(){return new Point(this.x,this.y)}
}
function Rect(p_x,p_y,lx,ly)
{
this.x=p_x;this.y=p_y;this.width=lx;this.height=ly;
this.clone=function(){return new Rect(this.x,this.y,this.width,this.height)}
this.equals=function(kpvpM){return(this.x==kpvpM.x)&&(this.y==kpvpM.y)&&(this.width==kpvpM.width)&&(this.height==kpvpM.height);}
this.copy=function(kpvpM){this.x=kpvpM.x;this.y=kpvpM.y;this.width=kpvpM.width;this.height=kpvpM.height;}
this.translate=function(QJeup,SITJT){this.x+=QJeup;this.y+=SITJT;}
this.isValid=function(){return(this.width>0)&&(this.height>0);}
}
var ifmEa=[
{acc:"e",l:["é","è","ë"]},{acc:"a",l:["à","ä","â","ã"]},{acc:"u",l:["ü","û"]},{acc:"c",l:["ç"]},{acc:"o",l:["ö","ô"]}
];
function removeAccentsFromString(s)
{
var res=s.toLowerCase();
for(var i=0;i<ifmEa.length;i++)
{
var array2=ifmEa[i].l;
for(var i2=0;i2<array2.length;i2++)
{
var reg=new RegExp(array2[i2],"g");
res=res.replace(reg,ifmEa[i].acc)
}
}
return res;
}
function IsNumeric(WbiKI)
{
var GoOAT="0123456789.";var EfWRm=true;var eALqc;
for(cnipN=0;cnipN<WbiKI.length&&EfWRm==true;cnipN++){eALqc=WbiKI.charAt(cnipN);if(GoOAT.indexOf(eALqc)==-1) EfWRm=false;}
return EfWRm;
}
function getDocumentSize()
{
return new Size(waJSQuery(document).width(),waJSQuery(document).height());
}
function getWindowSize()
{
if(isAppleMobile())
{
return new Size(window.innerWidth,window.innerHeight);
}
return new Size(waJSQuery(window).width(),waJSQuery(window).height());
}
function urlSuffixe(aeDpD_minuts)
{
var tAcMb=aeDpD_minuts*60;
var ZOcjI=new Date();
var XLmiM=0;
XLmiM+=ZOcjI.getYear()*12*31*24*60*60;
XLmiM+=ZOcjI.getMonth()*31*24*60*60;
XLmiM+=ZOcjI.getDate()*24*60*60;
XLmiM+=ZOcjI.getHours()*60*60;
XLmiM+=ZOcjI.getMinutes()*60;
XLmiM+=ZOcjI.getSeconds();
if(tAcMb!=0)
{
XLmiM=Math.floor(XLmiM/tAcMb)*tAcMb
}
return "-"+XLmiM;
}
function urlAntiCacheForPreview()
{
if(document.webaca_is_preview) return urlSuffixe(0);
return "";
}
function aFsaC()
{
var DMZFS=document.getElementsByTagName("A");
for(var cnipN=0;cnipN<DMZFS.length;cnipN++)
{
var kpvpM=DMZFS[cnipN];
if(kpvpM.onmouseover)kpvpM.onmouseover=null;
if(kpvpM.onmouseout)kpvpM.onmouseout=null;
}
}
function eGmOu()
{
for(var ivUmM in document.wa_global_list_element)
{
var UidRD=document.wa_global_list_element[ivUmM]
var VuVWl=document.getElementById(UidRD)
VuVWl.onclick=function()
{
WA_focus(this)
}
}
}
function WA_declare(UidRD)
{
if(!document.wa_global_list_element)
{
document.wa_global_list_element=new Array();;
}
document.wa_global_list_element.push(UidRD)
}
function hTlOA()
{
var wOMej=window.location.search;
if(wOMej.substr(0,1)=="?")wOMej=wOMej.substr(1);
if(wOMej.length==0)return;
var MUpPW=new Array();
var LqdOY=wOMej.split("&");
for(var i=0;i<LqdOY.length;i++)
{
var jOgpv=LqdOY[i].split("=");MUpPW[jOgpv[0]]=jOgpv[1];
}
var qqLBX_info=MUpPW["wa_key"];
if(!qqLBX_info)return;
var hfWId=new Array();
hfWId.m_unid=qqLBX_info;
hfWId.m_index_item=-1;
var emSxc_sep_info=qqLBX_info.indexOf("-");
if(emSxc_sep_info!=-1)
{
hfWId.m_unid=qqLBX_info.substring(0,emSxc_sep_info);
hfWId.m_index_item=parseInt(qqLBX_info.substring(emSxc_sep_info+1));
}
document.wa_global_query_info=hfWId;
}
function IS_onload_WA()
{
if(isAppleMobile())
{
aFsaC()
}
else
{
eGmOu()
}
hTlOA();

vKaDK()
}
function vKaDK()
{
var UWJsU=0;
var iMQoU=document.webaca_banner_height;
var SopZw=document.webaca_page_option_background
if(document.webaca_page_is_centered)
{
var GPqIM=getDocumentSize().width() 

var rvKXk=document.webaca_width_page
if((SopZw==0)||(SopZw==1))
{
if(GPqIM>rvKXk)UWJsU=(GPqIM-rvKXk)/2;
}
else
if(SopZw==2)
{
}
else
if(SopZw==3) 
{
UWJsU=GPqIM/2-(document.webaca_page_background_img_size[0]/2);
}
}
if(document.body&&document.body.style)
document.body.style.backgroundPosition=UWJsU+"px "+iMQoU+"px";
}
waJSQuery(window).resize(function(){
vKaDK()
});


function WA_loadMessages()
{
for(var k in CONST_WA_TR)
{
var key=CONST_WA_TR[k]
Translator.m_tr[key[0]]=key[1]
}
for(var n=0;n<CONST_WA_COUNTRIES.codes.length;n++)
{
var hMuVT=CONST_WA_COUNTRIES.codes[n]
var skiHD=CONST_WA_COUNTRIES.labels[n]
Translator.m_countries[hMuVT]=skiHD
}
}
function Translator()
{
}
Translator.m_tr=new Array();
Translator.m_countries=new Array();
Translator.tr=function(k,bEncodeBr)
{
try
{
var v=Translator.m_tr[k]
if((v==undefined)||(v.length==0))return "@"+k;
if(bEncodeBr!=false)
{
v=v.replace(/\n/g,"<br>")
}
return v
}
catch(e){}
return k;
}
Translator.country=function(k)
{
try
{
var v=Translator.m_countries[k]
if((v==undefined)||(v.length==0))return "@"+k;
return v
}
catch(e){}
return k;
}

function isOperaBrowser()
{
return(/opera/i.test(navigator.userAgent))
}
function WA_exec_callback_opera_compliant(qtwfu,KmOPp)
{
KmOPp.call(qtwfu)
}
function WA_exec_delayedCallback(qtwfu,KmOPp)
{
wa_timeout(Delegate.create(qtwfu,KmOPp),0);
}
function WA_loadScript(url,callback,params)
{
var e=document.createElement("script");
e.src=url;
e.type="text/javascript";
e.onerror=function(){callback(params,false);}
if(/msie/i.test(navigator.userAgent)&&!/opera/i.test(navigator.userAgent)){
e.onreadystatechange=function(){
if((this.readyState=='complete')||(this.readyState=='loaded')){
callback(params,true);
}
}
}else
{
e.onload=function(){
if(/opera/i.test(navigator.userAgent))
wa_timeout(callback,0,params,true);
else
callback(params,true);
}
}
document.getElementsByTagName("head")[0].appendChild(e);
}
function WA_onSearch(UidRD_input)
{
var iQpbM=document.getElementById(UidRD_input);
if(document.wa_search_js_loaded==true)
{
WA_openSearchDialog(iQpbM,document.const_wa_search_index_js)
}
else
{
WA_Dialog.progress();
rqJbN(iQpbM)
}
}
function aqOQN(DcOjp)
{
document.wa_search_js_loaded=true
WA_openSearchDialog(DcOjp[0],document.const_wa_search_index_js)
}
function rqJbN(iQpbM_field)
{
WA_loadScript(document.const_wa_search_js,aqOQN,[iQpbM_field])
}
function JsFjm(offset){
var endstr=document.cookie.indexOf(";",offset);
if(endstr==-1)
endstr=document.cookie.length;
return unescape(document.cookie.substring(offset,endstr));
}
function WA_GetCookie(name)
{
var arg=name+"=";
var alen=arg.length;
var clen=document.cookie.length;
var i=0;
while(i<clen)
{
var j=i+alen;
if(document.cookie.substring(i,j)==arg)
return JsFjm(j);
i=document.cookie.indexOf(" ",i)+1;
if(i==0) break;
}
return "";
}
function WA_SetCookie(name,value){
var argv=WA_SetCookie.arguments;
var argc=WA_SetCookie.arguments.length;
var expires=(argc>2)?argv[2]:null;
var path=(argc>3)?argv[3]:null;
var domain=(argc>4)?argv[4]:null;
var secure=(argc>5)?argv[5]:false;
document.cookie=name+"="+escape(value)+((expires==null)?"":("; expires="+expires.toGMTString()))+((path==null)?"":("; path="+path))+((domain==null)?"":("; domain="+domain))+((secure==true)?"; secure":"");
}

function MD5(string){
function RotateLeft(lValue,iShiftBits){
return(lValue<<iShiftBits)|(lValue>>>(32-iShiftBits));
}
function AddUnsigned(lX,lY){
var lX4,lY4,lX8,lY8,lResult;
lX8=(lX&0x80000000);
lY8=(lY&0x80000000);
lX4=(lX&0x40000000);
lY4=(lY&0x40000000);
lResult=(lX&0x3FFFFFFF)+(lY&0x3FFFFFFF);
if(lX4&lY4){
return(lResult^0x80000000^lX8^lY8);
}
if(lX4|lY4){
if(lResult&0x40000000){
return(lResult^0xC0000000^lX8^lY8);
}else{
return(lResult^0x40000000^lX8^lY8);
}
}else{
return(lResult^lX8^lY8);
}
}
function F(x,y,z){return(x&y)|((~x)&z);}
function G(x,y,z){return(x&z)|(y&(~z));}
function H(x,y,z){return(x^y^z);}
function I(x,y,z){return(y^(x|(~z)));}
function FF(a,b,c,d,x,s,ac){
a=AddUnsigned(a,AddUnsigned(AddUnsigned(F(b,c,d),x),ac));
return AddUnsigned(RotateLeft(a,s),b);
};
function GG(a,b,c,d,x,s,ac){
a=AddUnsigned(a,AddUnsigned(AddUnsigned(G(b,c,d),x),ac));
return AddUnsigned(RotateLeft(a,s),b);
};
function HH(a,b,c,d,x,s,ac){
a=AddUnsigned(a,AddUnsigned(AddUnsigned(H(b,c,d),x),ac));
return AddUnsigned(RotateLeft(a,s),b);
};
function II(a,b,c,d,x,s,ac){
a=AddUnsigned(a,AddUnsigned(AddUnsigned(I(b,c,d),x),ac));
return AddUnsigned(RotateLeft(a,s),b);
};
function ConvertToWordArray(string){
var lWordCount;
var lMessageLength=string.length;
var lNumberOfWords_temp1=lMessageLength+8;
var lNumberOfWords_temp2=(lNumberOfWords_temp1-(lNumberOfWords_temp1%64))/64;
var lNumberOfWords=(lNumberOfWords_temp2+1)*16;
var lWordArray=Array(lNumberOfWords-1);
var lBytePosition=0;
var lByteCount=0;
while(lByteCount<lMessageLength){
lWordCount=(lByteCount-(lByteCount%4))/4;
lBytePosition=(lByteCount%4)*8;
lWordArray[lWordCount]=(lWordArray[lWordCount]|(string.charCodeAt(lByteCount)<<lBytePosition));
lByteCount++;
}
lWordCount=(lByteCount-(lByteCount%4))/4;
lBytePosition=(lByteCount%4)*8;
lWordArray[lWordCount]=lWordArray[lWordCount]|(0x80<<lBytePosition);
lWordArray[lNumberOfWords-2]=lMessageLength<<3;
lWordArray[lNumberOfWords-1]=lMessageLength>>>29;
return lWordArray;
};
function WordToHex(lValue){
var WordToHexValue="",WordToHexValue_temp="",lByte,lCount;
for(lCount=0;lCount<=3;lCount++){
lByte=(lValue>>>(lCount*8))&255;
WordToHexValue_temp="0"+lByte.toString(16);
WordToHexValue=WordToHexValue+WordToHexValue_temp.substr(WordToHexValue_temp.length-2,2);
}
return WordToHexValue;
};
function Utf8Encode(string){
string=string.replace(/\r\n/g,"\n");
var utftext="";
for(var n=0;n<string.length;n++){
var c=string.charCodeAt(n);
if(c<128){
utftext+=String.fromCharCode(c);
}
else if((c>127)&&(c<2048)){
utftext+=String.fromCharCode((c>>6)|192);
utftext+=String.fromCharCode((c&63)|128);
}
else{
utftext+=String.fromCharCode((c>>12)|224);
utftext+=String.fromCharCode(((c>>6)&63)|128);
utftext+=String.fromCharCode((c&63)|128);
}
}
return utftext;
};
var x=Array();
var k,AA,BB,CC,DD,a,b,c,d;
var S11=7,S12=12,S13=17,S14=22;
var S21=5,S22=9,S23=14,S24=20;
var S31=4,S32=11,S33=16,S34=23;
var S41=6,S42=10,S43=15,S44=21;
string=Utf8Encode(string);
x=ConvertToWordArray(string);
a=0x67452301;b=0xEFCDAB89;c=0x98BADCFE;d=0x10325476;
for(k=0;k<x.length;k+=16){
AA=a;BB=b;CC=c;DD=d;
a=FF(a,b,c,d,x[k+0],S11,0xD76AA478);
d=FF(d,a,b,c,x[k+1],S12,0xE8C7B756);
c=FF(c,d,a,b,x[k+2],S13,0x242070DB);
b=FF(b,c,d,a,x[k+3],S14,0xC1BDCEEE);
a=FF(a,b,c,d,x[k+4],S11,0xF57C0FAF);
d=FF(d,a,b,c,x[k+5],S12,0x4787C62A);
c=FF(c,d,a,b,x[k+6],S13,0xA8304613);
b=FF(b,c,d,a,x[k+7],S14,0xFD469501);
a=FF(a,b,c,d,x[k+8],S11,0x698098D8);
d=FF(d,a,b,c,x[k+9],S12,0x8B44F7AF);
c=FF(c,d,a,b,x[k+10],S13,0xFFFF5BB1);
b=FF(b,c,d,a,x[k+11],S14,0x895CD7BE);
a=FF(a,b,c,d,x[k+12],S11,0x6B901122);
d=FF(d,a,b,c,x[k+13],S12,0xFD987193);
c=FF(c,d,a,b,x[k+14],S13,0xA679438E);
b=FF(b,c,d,a,x[k+15],S14,0x49B40821);
a=GG(a,b,c,d,x[k+1],S21,0xF61E2562);
d=GG(d,a,b,c,x[k+6],S22,0xC040B340);
c=GG(c,d,a,b,x[k+11],S23,0x265E5A51);
b=GG(b,c,d,a,x[k+0],S24,0xE9B6C7AA);
a=GG(a,b,c,d,x[k+5],S21,0xD62F105D);
d=GG(d,a,b,c,x[k+10],S22,0x2441453);
c=GG(c,d,a,b,x[k+15],S23,0xD8A1E681);
b=GG(b,c,d,a,x[k+4],S24,0xE7D3FBC8);
a=GG(a,b,c,d,x[k+9],S21,0x21E1CDE6);
d=GG(d,a,b,c,x[k+14],S22,0xC33707D6);
c=GG(c,d,a,b,x[k+3],S23,0xF4D50D87);
b=GG(b,c,d,a,x[k+8],S24,0x455A14ED);
a=GG(a,b,c,d,x[k+13],S21,0xA9E3E905);
d=GG(d,a,b,c,x[k+2],S22,0xFCEFA3F8);
c=GG(c,d,a,b,x[k+7],S23,0x676F02D9);
b=GG(b,c,d,a,x[k+12],S24,0x8D2A4C8A);
a=HH(a,b,c,d,x[k+5],S31,0xFFFA3942);
d=HH(d,a,b,c,x[k+8],S32,0x8771F681);
c=HH(c,d,a,b,x[k+11],S33,0x6D9D6122);
b=HH(b,c,d,a,x[k+14],S34,0xFDE5380C);
a=HH(a,b,c,d,x[k+1],S31,0xA4BEEA44);
d=HH(d,a,b,c,x[k+4],S32,0x4BDECFA9);
c=HH(c,d,a,b,x[k+7],S33,0xF6BB4B60);
b=HH(b,c,d,a,x[k+10],S34,0xBEBFBC70);
a=HH(a,b,c,d,x[k+13],S31,0x289B7EC6);
d=HH(d,a,b,c,x[k+0],S32,0xEAA127FA);
c=HH(c,d,a,b,x[k+3],S33,0xD4EF3085);
b=HH(b,c,d,a,x[k+6],S34,0x4881D05);
a=HH(a,b,c,d,x[k+9],S31,0xD9D4D039);
d=HH(d,a,b,c,x[k+12],S32,0xE6DB99E5);
c=HH(c,d,a,b,x[k+15],S33,0x1FA27CF8);
b=HH(b,c,d,a,x[k+2],S34,0xC4AC5665);
a=II(a,b,c,d,x[k+0],S41,0xF4292244);
d=II(d,a,b,c,x[k+7],S42,0x432AFF97);
c=II(c,d,a,b,x[k+14],S43,0xAB9423A7);
b=II(b,c,d,a,x[k+5],S44,0xFC93A039);
a=II(a,b,c,d,x[k+12],S41,0x655B59C3);
d=II(d,a,b,c,x[k+3],S42,0x8F0CCC92);
c=II(c,d,a,b,x[k+10],S43,0xFFEFF47D);
b=II(b,c,d,a,x[k+1],S44,0x85845DD1);
a=II(a,b,c,d,x[k+8],S41,0x6FA87E4F);
d=II(d,a,b,c,x[k+15],S42,0xFE2CE6E0);
c=II(c,d,a,b,x[k+6],S43,0xA3014314);
b=II(b,c,d,a,x[k+13],S44,0x4E0811A1);
a=II(a,b,c,d,x[k+4],S41,0xF7537E82);
d=II(d,a,b,c,x[k+11],S42,0xBD3AF235);
c=II(c,d,a,b,x[k+2],S43,0x2AD7D2BB);
b=II(b,c,d,a,x[k+9],S44,0xEB86D391);
a=AddUnsigned(a,AA);
b=AddUnsigned(b,BB);
c=AddUnsigned(c,CC);
d=AddUnsigned(d,DD);
}
var temp=WordToHex(a)+WordToHex(b)+WordToHex(c)+WordToHex(d);
return temp.toLowerCase();
}
function centerTextContent(kpvpM)
{
var skiHD=kpvpM.html()
kpvpM.html("<div class='inner-content' style='position:absolute;'></div>")
var XPMGX=kpvpM.find(".inner-content")
XPMGX.html(skiHD)
XPMGX.css({top:(kpvpM.height()-XPMGX.height())/2,left:(kpvpM.width()-XPMGX.width())/2})
}
function centerElement(WDlTd,eRMen)
{
var liQoG=WDlTd.children(eRMen)
liQoG.css("left",(WDlTd.width()-liQoG.width())/2)
liQoG.css("top",(WDlTd.height()-liQoG.height())/2)
}
function splitClassParameters(s,sep1,sep2)
{
s=jQuery.trim(s);
var arr=new Array()
var clName=""
var clParam=""
var c;
for(var i=0;i<s.length;i++)
{
c=s.charAt(i)
if((c==' ')||(c=='\n')||(c==sep2))
{
arr[clName]=clParam;
clName=""
clParam=""
}
else
if(c==sep1)
{
var GRfvF=0;
var OwSQq=true;
do
{
OwSQq=true;
i++;
c=s.charAt(i)
if(c==sep1)
{
GRfvF++;
}
if((c!=sep2)||(GRfvF!=0))
{
clParam+=c;
}
if(GRfvF>0)
if(c==sep2)
{
GRfvF--;
OwSQq=false
}
}
while((OwSQq==false)||(c!=sep2)||(GRfvF!=0)) 
}
else
{
clName+=c;
}
}
if(clName.length>0)
{
arr[clName]=clParam;
}
return arr;
}
function splitClass(s)
{
var arr=splitClassParameters(s,'[',']')
for(k in arr)
{
var v=arr[k];
if(v.length>0)
{
var arr2=splitClassParameters(v,'(',')')
for(k2 in arr2)
{
alert("#"+k+"  "+k2+" = "+arr2[k2])
}
}
}
}
function extractClassInfo(s,className)
{
var arr=splitClassParameters(s,'[',']')
for(k in arr)
{
var v=arr[k];
if(v.length>0)
{
if(k==className)
{
var arr2=splitClassParameters(v,'(',')') 

return arr2;
}
}
}
return null
}
function extractParamInfo(kpvpM,ZvTuo,pjEIx)
{
if(pjEIx==undefined)pjEIx="param"
if(kpvpM==undefined) return ""
var jjWKX=kpvpM.attr("class");
if(jjWKX==undefined) return ""
var YoPvl=extractClassInfo(jjWKX,pjEIx);
if(YoPvl==null) return ""
if(YoPvl==undefined) return ""
if(YoPvl[ZvTuo]==undefined) return ""
if(ZvTuo) return  YoPvl[ZvTuo]
return YoPvl;
}


function getBrowserInfos()
{
var vtIHf={
}
if(waJSQuery.browser.webkit)vtIHf.engine="webkit"
if(waJSQuery.browser.mozilla)vtIHf.engine="ff"
if(waJSQuery.browser.msie)vtIHf.engine="ie"
return vtIHf
}
function waSetVisibilityMainPageContenair(GIgNM)
{
if(GIgNM)
{
waJSQuery(".wa-video").show()
}
else
{
waJSQuery(".wa-video").hide()
}
}
function isValidEmailAddress(lUwGn)
{
var CbZrb=new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
return CbZrb.test(lUwGn);
}
function asvfA(c,x,y,lx,ly)
{
c.beginPath();
c.moveTo(x,y);
c.lineTo(x+lx,y);
c.lineTo(x+lx,y+ly);
c.lineTo(x,y+ly);
c.lineTo(x,y);
c.closePath();
}
function PQNKo(c,x,y,lx,ly,bJlfP,oZjKi)
{
if(typeof(bJlfP)=="number")
{
bJlfP=[bJlfP,bJlfP,bJlfP,bJlfP]
}
if(oZjKi)
{
c.moveTo(x+bJlfP[0],y);c.lineTo(x+lx-bJlfP[1],y);c.quadraticCurveTo(x+lx,y,x+lx,y+bJlfP[1]);c.lineTo(x+lx,y+ly-bJlfP[2]);c.quadraticCurveTo(x+lx,y+ly,x+lx-bJlfP[2],y+ly);c.lineTo(x+bJlfP[3],y+ly);c.quadraticCurveTo(x,y+ly,x,y+ly-bJlfP[3]);c.lineTo(x,y+bJlfP[0]);c.quadraticCurveTo(x,y,x+bJlfP[0],y);
return;
}
c.moveTo(x,y+bJlfP[0]);c.lineTo(x,y+ly-bJlfP[3]);c.quadraticCurveTo(x,y+ly,x+bJlfP[3],y+ly);c.lineTo(x+lx-bJlfP[2],y+ly);c.quadraticCurveTo(x+lx,y+ly,x+lx,y+ly-bJlfP[2]);c.lineTo(x+lx,y+bJlfP[1]);c.quadraticCurveTo(x+lx,y,x+lx-bJlfP[1],y);c.lineTo(x+bJlfP[0],y);c.quadraticCurveTo(x,y,x,y+bJlfP[0]);
}
function waExtractCssStyle(qqLBX,hMuVT)
{
return VfYow(qqLBX,hMuVT);
}
function VfYow(qqLBX,hMuVT)
{
if(qqLBX==undefined) return ""
var pDHHp=qqLBX.indexOf(hMuVT);
if((pDHHp>-1)||((pDHHp>0)&&(qqLBX.substring(pDHHp-1)==";")))
{
qqLBX=qqLBX.substring(pDHHp)
pDHHp=qqLBX.indexOf(";");
if(pDHHp>-1)
{
qqLBX=qqLBX.substring(0,pDHHp) 
pDHHp=qqLBX.indexOf(":");
if(pDHHp>-1)
{
qqLBX=qqLBX.substring(pDHHp+1)
}
return waJSQuery.trim(qqLBX);
}
else
{
pDHHp=qqLBX.indexOf(":");
if(pDHHp>-1)
{
qqLBX=qqLBX.substring(pDHHp+1)
}
return waJSQuery.trim(qqLBX);
}
}
return "";
}
function waExtractRadiusFromCss(kpvpM)
{
var JxMlS=0;
var LPTwk=kpvpM.attr("style");
var uLsKe="border-radius"
if(isMSIE_higher_than_ie8())
{
uLsKe="-moz-border-radius" 
}
var  GtNhD=VfYow(LPTwk,uLsKe) 
if(GtNhD.length==0)
{
var oMsnq=VfYow(LPTwk,"border-top-left-radius")
var luKbY=VfYow(LPTwk,"border-top-right-radius")
var cIhIf=VfYow(LPTwk,"border-bottom-right-radius")
var VcGsc=VfYow(LPTwk,"border-bottom-left-radius") 
if(oMsnq.length==0)oMsnq="0px"
if(luKbY.length==0)luKbY="0px"
if(cIhIf.length==0)cIhIf="0px"
if(VcGsc.length==0)VcGsc="0px"
GtNhD=oMsnq+" "+luKbY+" "+cIhIf+" "+VcGsc 


}
var splitradiusStr=GtNhD.split(" ") 

var luKbY=Math.max(0,parseInt(splitradiusStr[0])-JxMlS)
var cIhIf=Math.max(0,parseInt(splitradiusStr[1])-JxMlS)
var VcGsc=Math.max(0,parseInt(splitradiusStr[2])-JxMlS)
var dvcKL=Math.max(0,parseInt(splitradiusStr[3])-JxMlS)
if(splitradiusStr.length==1)
{
cIhIf=luKbY;VcGsc=luKbY;dvcKL=luKbY;
}
if(isNaN(luKbY))luKbY=0
if(isNaN(cIhIf))cIhIf=luKbY
if(isNaN(VcGsc))VcGsc=cIhIf
if(isNaN(dvcKL))dvcKL=VcGsc
return new Array(luKbY,cIhIf,VcGsc,dvcKL)
}
function waSoustractFromArrayRadius(DWBXb,TggGi)
{
for(var i=0;i<DWBXb.length;i++)
{
if(isNaN(DWBXb[i])||(DWBXb[i].length==0))
{
DWBXb[i]=0
}
else
{
DWBXb[i]=Math.max(0,DWBXb[i]-TggGi)
}
}
return DWBXb;
}
function waGenerateNewGradientID()
{
var aQNIQ=waJSQuery(document).data("curCanvasGradientId")
if(aQNIQ==undefined)aQNIQ=0;
waJSQuery(document).data("curCanvasGradientId",aQNIQ+1)
return "canvasGradientId"+aQNIQ;
}
function waGetDrawingSurface(kpvpM,ZHOUa,fWgAT)
{
var bookd="wa-div-bg-gradient" 
var rxJSH=null
var sKxgw=kpvpM.find("."+bookd) 
if(sKxgw.length==0)
{

var wSBmM=-1;
kpvpM.append("<div class='"+bookd+"' ></div>")
sKxgw=kpvpM.find("."+bookd)
sKxgw.css({position:"absolute",top:0,left:0,width:ZHOUa,height:fWgAT,zIndex:wSBmM})
var ouiWR=waGenerateNewGradientID();
sKxgw.html("<canvas id='"+ouiWR+"' width="+ZHOUa+" height="+fWgAT+" style='z-index:"+wSBmM+"' ></canvas>")
sKxgw.data("waCanvasId",ouiWR)
rxJSH=document.getElementById(ouiWR);
if(isMSIE_lower_than_ie9())
{
if(window.G_vmlCanvasManager)
window.G_vmlCanvasManager.initElement(rxJSH);
}
}
else
{
var ouiWR=sKxgw.data("waCanvasId")
rxJSH=document.getElementById(ouiWR);
}
if(rxJSH==null)
{
if(isMSIE())
{
if(document.documentMode==8)
{
if(/MSIE 9/.test(navigator.userAgent))
{
if(document.warning_ie9_frame!=true)
{
document.warning_ie9_frame=true
alert(window.location+"\n"+Translator.tr("This site is probably in a frame,Display problems can occur with IE9 you have to enabled Force IE8 rendering in WA4 website properties",false));
}
}
}
}
return null;
}
var FZbhn=rxJSH.getContext('2d');
return FZbhn;
}
function cLDfL(FZbhn,qcSgT)
{
var Wtlpq=qcSgT.split(" ")
if(Wtlpq.length>1)
{
var GbtKR=parseInt(Wtlpq[0]);
var tTICq=parseInt(Wtlpq[1]);;
var feNUc=parseInt(Wtlpq[2]);
var hUNci=parseInt(Wtlpq[3]);
var kpMai=Wtlpq[4]
var NUNRJ="";
if(Wtlpq.length>5)
{
NUNRJ=Wtlpq[5]
}
if(kpMai=="undefined")kpMai=""
if(NUNRJ=="undefined")NUNRJ="" 



if(NUNRJ=="")NUNRJ=kpMai
if(isMSIE_lower_than_ie9())
{

var VAuTU=new RGBColor(kpMai)
var iTXjE=new RGBColor(NUNRJ)
if(kpMai=="")
{
var AXBMf=new RGBColor(NUNRJ)
AXBMf.a=0;
kpMai=AXBMf.toRGB()
}
if(NUNRJ=="")
{
var AXBMf=new RGBColor(kpMai)
AXBMf.a=0;
NUNRJ=AXBMf.toRGB()
}
}





var jmbnV=FZbhn.createLinearGradient(GbtKR,tTICq,feNUc,hUNci);
jmbnV.addColorStop(0,kpMai);
jmbnV.addColorStop(1,NUNRJ);


return jmbnV
}
else
{
return qcSgT
}
}
function waDrawRoundedRectInSurface(FZbhn,ZHOUa,fWgAT,bJlfP,qcSgT,JxMlS,NsBgG)
{

if((NsBgG==undefined)||(NsBgG.length==0))
{
JxMlS=0
}
if(JxMlS==0)
{
NsBgG=""
}
var rGYxL=ZHOUa-2*JxMlS
var nGWkq=fWgAT-2*JxMlS
var exnMi=new Array(bJlfP[0],bJlfP[1],bJlfP[2],bJlfP[3])
exnMi=waSoustractFromArrayRadius(exnMi,JxMlS)
if(qcSgT!=null)
{
{
FZbhn.fillStyle=cLDfL(FZbhn,qcSgT) 
var QJeup=JxMlS
var SITJT=JxMlS
if(FZbhn.fillStyle!="")
{
FZbhn.beginPath();
PQNKo(FZbhn,QJeup,SITJT,rGYxL,nGWkq,exnMi)
FZbhn.closePath();
FZbhn.fill()
}
}
}
if((JxMlS>0)&&(NsBgG)&&(NsBgG.length>0))
{
FZbhn.fillStyle=NsBgG;
FZbhn.beginPath();
PQNKo(FZbhn,0,0,ZHOUa,fWgAT,bJlfP)
PQNKo(FZbhn,JxMlS,JxMlS,rGYxL,nGWkq,exnMi,true)
FZbhn.closePath();
FZbhn.fill()
}
}
function waDrawRoundedRect(kpvpM,ZHOUa,fWgAT,bJlfP,qcSgT,JxMlS,NsBgG)
{
var FZbhn=waGetDrawingSurface(kpvpM,ZHOUa,fWgAT)
waDrawRoundedRectInSurface(FZbhn,ZHOUa,fWgAT,bJlfP,qcSgT,JxMlS,NsBgG)
}
function waDrawButton(kpvpM,qcSgT,NsBgG,phEWY,OSKKC)
{
var RVomS=kpvpM.parent()
var pXhwh=RVomS.find(".waButInner")
pXhwh.hide()
var WKWAL=RVomS.find(".waButGlossInner")
WKWAL.hide()
kpvpM.css("background","")
kpvpM.css("border","none")
var JxMlS=1;
if((NsBgG==undefined)||(NsBgG.length==0))
{
JxMlS=0;
}
var FZPoc=1;
var tZONg=kpvpM.outerWidth()
var utNhL=kpvpM.outerHeight()
var ZHOUa=tZONg
var fWgAT=utNhL
var pJPBG=(extractParamInfo(kpvpM,"aqua")=="1")
var bJlfP=waExtractRadiusFromCss(kpvpM)
var FZbhn=waGetDrawingSurface(kpvpM,ZHOUa,fWgAT) 
if(isMSIE_lower_than_ie9())
{
kpvpM.css("border","")
}
FZbhn.clearRect(0,0,ZHOUa,fWgAT)
var DhtKo=NsBgG
if(isMSIE_lower_than_ie9())
{
var MMoHE=qcSgT.split(" ")
var kpMai=""
var NUNRJ="" 
if(MMoHE.length<=1)
{
kpMai=qcSgT
NUNRJ=qcSgT
}
else
{
kpMai=MMoHE[4]
NUNRJ=MMoHE[5]
}
if(kpMai==NUNRJ)
{
waDrawRoundedRectInSurface(FZbhn,ZHOUa,fWgAT,bJlfP,kpMai,JxMlS,DhtKo)
}
else
{
var Flevm=40;
if(pJPBG)
{
Flevm=70;
}
var VGUjV=fWgAT-Math.round(fWgAT*Flevm/100)
var luKbY=[bJlfP[0],bJlfP[1],0,0]
waDrawRoundedRectInSurface(FZbhn,ZHOUa,fWgAT-VGUjV,luKbY,kpMai,JxMlS,"")
var cIhIf=[0,0,bJlfP[2],bJlfP[3]]
var btKkQ="0 0 0 "+VGUjV+" "+kpMai+" "+NUNRJ
FZbhn.fillStyle=cLDfL(FZbhn,btKkQ)
FZbhn.beginPath();
var EBAwl=fWgAT-VGUjV
PQNKo(FZbhn,0,EBAwl,ZHOUa,VGUjV,cIhIf)
FZbhn.closePath();
FZbhn.fill() 
if((DhtKo.length>0)&&(JxMlS>0))
{
FZbhn.fillStyle=""
FZbhn.strokeStyle=DhtKo;
FZbhn.beginPath();
PQNKo(FZbhn,0,0,ZHOUa,fWgAT,bJlfP)
FZbhn.closePath();
FZbhn.stroke();
}
}
}
else
{

waDrawRoundedRectInSurface(FZbhn,ZHOUa,fWgAT,bJlfP,qcSgT,JxMlS,DhtKo)
}
if(phEWY&&(phEWY.length>0))
{
FZbhn.fillStyle=""
if(isMSIE_lower_than_ie9())
{
FZbhn.strokeStyle=phEWY;
}
else
{
FZbhn.strokeStyle=cLDfL(FZbhn,"0 "+Math.round(fWgAT/2)+" 0 "+fWgAT+" "+phEWY+" transparent") 
}
FZbhn.beginPath();
PQNKo(FZbhn,1.5,1.5,ZHOUa-3,fWgAT-3,bJlfP)
FZbhn.closePath();
FZbhn.stroke()
}
if(pJPBG)
{
var kpMai="rgba(255,255,255,0.5)"
var NUNRJ="rgba(255,255,255,0.1)"
var VGUjV=Math.round(fWgAT*0.5);
var dVmnG=bJlfP[0]
var AVXEn=dVmnG;
AVXEn=Math.min(AVXEn,VGUjV/2);
var FkLwc=dVmnG-AVXEn;
FkLwc=Math.max(FkLwc,0);
var qcSgT="0 0 0 "+VGUjV+" "+kpMai+" "+NUNRJ 
FZbhn.fillStyle=cLDfL(FZbhn,qcSgT)
FZbhn.beginPath();
var EBAwl=0
PQNKo(FZbhn,FkLwc,EBAwl,ZHOUa-2*FkLwc,EBAwl+VGUjV,AVXEn)
FZbhn.closePath();
FZbhn.fill()
}
}
function waHackGradient()
{
if(isWebKit()||isFirefox())
{
return false;
}
waJSQuery(".wa-bg-gradient").each(function()
{
var kpvpM=waJSQuery(this)
var LPTwk=kpvpM.attr("style");
var qcSgT=extractParamInfo(kpvpM,"grad") 
var DmhiN_borderProps=extractParamInfo(kpvpM,"border").split(" ")
var JxMlS=0
var NsBgG=""
if(DmhiN_borderProps.length>0)
{
JxMlS=parseInt(DmhiN_borderProps[0])
if(isNaN(JxMlS))JxMlS=0;
}
if(DmhiN_borderProps.length>1)
{
NsBgG=DmhiN_borderProps[1]
}
var HHsCv=kpvpM.css("backgroundImage")
if((HHsCv.length>0)&&(HHsCv!="none"))
{
qcSgT=null
}
var ZHOUa=kpvpM.width()+2*JxMlS
var fWgAT=kpvpM.height()+2*JxMlS
var bJlfP=waExtractRadiusFromCss(kpvpM)
kpvpM.css({border:"0px none",backgroundColor:"transparent"}) 
waDrawRoundedRect(kpvpM,ZHOUa,fWgAT,bJlfP,qcSgT,JxMlS,NsBgG)
if(isMSIE())
{
kpvpM.css({width:ZHOUa,height:fWgAT})
}
})
}
function waHasButtonHacking()
{
if(isWebKit()||isFirefox())
{
return false;
}
return true;
}
function waHackButtons()
{
if(waHasButtonHacking()==false)
{
return false;
}
waJSQuery(".wa-button").each(function()
{
var kpvpM=waJSQuery(this)
waHackButton(kpvpM)
})
}
function waPercentGradientButton(lCKPx)
{
var pJPBG=(extractParamInfo(lCKPx,"aqua")=="1")
var BeXTS=40;
if(pJPBG)
{
BeXTS=70;
}
return BeXTS;
}
function waHackButton(kpvpM)
{
var RVomS=kpvpM.parent()
var pXhwh=RVomS.find(".waButInner") 
pXhwh.show()
var WKWAL=RVomS.find(".waButGlossInner")
WKWAL.show()
if(waHasButtonHacking()==false)
{
return false;
}
var ChOwm=kpvpM.data("saved-background-image")
if(ChOwm==null)
{
kpvpM.data("saved-background-image",kpvpM.css("background-image"))
}
var sWntp=kpvpM.data("saved-background-image")
if((sWntp.indexOf("url(")>-1)&&(sWntp.indexOf("wa_transparent.gif")==-1))
{
return false;
}

kpvpM.css("background-color","")
var qcSgT=extractParamInfo(kpvpM,"grad")
var phEWY=(extractParamInfo(kpvpM,"inborder"))
var NsBgG=(extractParamInfo(kpvpM,"border"))
waDrawButton(kpvpM,qcSgT,NsBgG,phEWY)
}
function waHackButtonOver(kpvpM)
{
if(waHasButtonHacking()==false)
{
return false;
}
var lCKPx=waJSQuery(">button",kpvpM);
var height=parseInt(kpvpM.css("height"));
var cl=kpvpM.attr("class")
var bg=extractParamInfo(kpvpM,"bg")
var qcSgT=null;
var BeXTS=waPercentGradientButton(lCKPx)
if(bg&&(bg.length>0))
{
var VGUjV=Math.round(height*BeXTS/100)
var cols=bg.split(" ")
qcSgT="0 "+VGUjV+" 0 "+height+" "+cols[0]+" "+cols[1]
}
var bg_img=extractParamInfo(kpvpM,"bg_img")
if(bg_img&&(bg_img.length>0))
{
return;
}
var NsBgG=extractParamInfo(kpvpM,"bord");
var phEWY=extractParamInfo(kpvpM,"inner_bord") 
waDrawButton(lCKPx,qcSgT,NsBgG,phEWY)
}
function waHackButtonOut(kpvpM)
{
waHackButton(kpvpM)
}
function waActivateOverButton(umrDf)
{
var pmcAX=true;
var BMfuQ=null
if(pmcAX)
{
BMfuQ=umrDf;
}
else
{
BMfuQ=waJSQuery(">span",umrDf);
}
var o=BMfuQ
var button=waJSQuery(">button",o);
var txtSpan=null
if(pmcAX)
{
txtSpan=waJSQuery(">div",button);

}
else
{
txtSpan=waJSQuery(">span",button);
}
var kGhcL=umrDf.attr("onclick")
if(kGhcL=="javascript:void(0)")kGhcL=""
if(kGhcL==undefined)kGhcL=""
if(kGhcL=="#")kGhcL=""
if((o.hasClass('wa-js-action')==false)&&(kGhcL.length==0))
{
umrDf.css("cursor","default")
o.css("cursor","default")
button.css("cursor","default")
txtSpan.css("cursor","default")
}
else
{
umrDf.css("cursor","pointer")
o.css("cursor","pointer")
button.css("cursor","pointer")
txtSpan.css("cursor","pointer")
}

if(isMSIE())
{
var XjrQY=false;
var liQoG=button.css("background-image")
if((liQoG&&(liQoG.length==0))||(liQoG=="none"))
{
button.css("background-image","url(wa_transparent.gif)") 
BMfuQ.append("<div style='position:absolute;top:0px;left:0px;width:100%;height:100%;;background-image:url(wa_transparent.gif)'></div>")
}
else
{
XjrQY=true;
button.css("background-size",button.width()+" px "+button.height()+" px ")
}
}
var pXhwh=o.find(".waButInner")
var rMkpd=txtSpan.outerWidth()
rMkpd=Math.min(rMkpd,button.width())
var img=waJSQuery(">img",button);
var HmsKO=Math.round((button.width()-rMkpd)/2)
var KQtOS=Math.round((button.height()-txtSpan.outerHeight())/2) 
var OvCmK=button.css("textAlign");
if(OvCmK=="center")
{
HmsKO=Math.round((button.width()-rMkpd)/2)
}
if(OvCmK=="left")
{
HmsKO=3
}
if(OvCmK=="right")
{
HmsKO=button.width()-rMkpd-3
}
if((img.length==0)||(img.attr("src")==undefined))
{


}
var cl=o.attr("class")
var clParam=extractClassInfo(cl,"param")
pXhwh.css("border-bottom","0px none")
var aHveJ=o
aHveJ=BMfuQ 
aHveJ.data("link_data",o)
if(clParam!=null)
aHveJ.hover(function(){
var o=waJSQuery(this).data("link_data")
var button=waJSQuery(">button",o);
var vGCOi=button.data("waButState")
if(vGCOi==undefined) vGCOi=0;
if(vGCOi!=0) return;
button.data("waButState",1)
var height=button.outerHeight()
var pJPBG=(extractParamInfo(button,"aqua")=="1")
var txtSpan=button.find(".wa-but-txt") 


var imgTag=waJSQuery(">img",button);
imgTag=button.find("img");
var innerSpan=waJSQuery(">.waButInner",o);
button.data('wa-style',button.attr('style'))
if(isMSIE_lower_than_ie9())
{
button.data('wa-style-bg-img',button.css('background-image'))
}
txtSpan.data('wa-style',txtSpan.attr('style'))
imgTag.data('wa-style',imgTag.attr('style'))
innerSpan.data('wa-style',innerSpan.attr('style'))
imgTag.data('wa-style-src',imgTag.attr('src')) 
{
var bg=extractParamInfo(o,"bg")
if(bg.length>0)
{
var cols=bg.split(" ")
var kpMai=cols[0]
var NUNRJ=kpMai
if(cols.length>1)NUNRJ=cols[1]
var dsven=getBrowserInfos();
var BeXTS=waPercentGradientButton(button)
if(dsven.engine=="webkit")
{
var VGUjV=Math.round(height*BeXTS/100) 
button.css("background","-webkit-gradient(linear,0 "+VGUjV+", 0 "+height+",from("+kpMai+"),to("+NUNRJ+"))")
}
if(dsven.engine=="ff")
{
button.css("background","-moz-linear-gradient(top left -90deg,"+kpMai+" "+BeXTS+"%, "+NUNRJ+" 100%)")
}
}
var borderCol=extractParamInfo(button,"border");
var borderColOver=extractParamInfo(o,"bord");
var whpaM=new RGBColor(borderColOver)
var pCnAD=whpaM.a>0;
var lDAGp=new RGBColor(borderCol)
var NnGPv=lDAGp.a>0;
if(pCnAD)
{
button.css("border","1px solid "+borderColOver)
}
else
{
button.css("border","0px")
}
var bg_img=extractParamInfo(o,"bg_img");
if(bg_img&&(bg_img.length>0))
{

var LQrYb=button.width();
var MiVvT=button.height();
if((NnGPv))
{
LQrYb+=2;
MiVvT+=2;
}
button.css({"background-image":"url('"+bg_img+"')","background-size":""+LQrYb+"px "+MiVvT+"px"})
}
}
var inner_borderCol=extractParamInfo(o,"inner_bord");
if(inner_borderCol&&(inner_borderCol.length>0))
{
innerSpan.css("border-color",inner_borderCol)
}
var txtCol=extractParamInfo(o,"txt");
if(txtCol&&(txtCol.length>0))
{
txtSpan.css("color",txtCol)
button.css("color",txtCol)
}
var aHMxZ=extractParamInfo(o,"u");
if(aHMxZ&&(aHMxZ.length>0))
{
if(aHMxZ=="1")
{
txtSpan.css("textDecoration","underline")
if(isMSIE())
{
button.css("textDecoration","underline")
}
}
else
{
txtSpan.css("textDecoration","none")
if(isMSIE())
{
button.css("textDecoration","none")
}
}
}
var img=extractParamInfo(o,"img");
if(img!=undefined)
{
if(img.length==0)
{
imgTag.css("width",0)
}
else
{
var img_pars=img.split(" ")
imgTag.attr("src",img_pars[0])
imgTag.css("width",img_pars[1])
imgTag.css("height",img_pars[2])
}
}
{
waHackButtonOver(o)
}
},function(){
var o=waJSQuery(this).data("link_data") 
var button=waJSQuery(">button",o);
var vGCOi=button.data("waButState")
if(vGCOi==undefined)vGCOi=0;
if(vGCOi!=1) return;
button.data("waButState",0)
var txtSpan=button.find(".wa-but-txt")
var imgTag=waJSQuery(">img",button);
imgTag=button.find("img");
var innerSpan=waJSQuery(">.waButInner",o);
button.attr("style",button.data("wa-style"))
if(isMSIE_lower_than_ie9())
{
button.css("background-image",button.data("wa-style-bg-img"))
}
txtSpan.attr("style",txtSpan.data("wa-style"))
imgTag.attr("style",imgTag.data("wa-style"))
imgTag.attr("src",imgTag.data("wa-style-src"))
innerSpan.attr("style",innerSpan.data("wa-style"))
waHackButtonOut(button)
});
}
function waActivateOverButtons()
{
waJSQuery(".wa-button-link").each(function(i)
{
var kpvpM=waJSQuery(this) 
waActivateOverButton(kpvpM)
})
}
function xFsQh(kpvpM)
{
wa_timeout(function(){xFsQh(kpvpM)},1000)
var korDG=kpvpM.find("div")
korDG.position().top
var DcOjp=korDG.data("data-marquee")
var SFStB=DcOjp.orientation
var wUVlb=DcOjp.speed
}
function xeQFO(korDG,now,fx)
{
if(isMSIE())
{
var DcOjp=korDG.data("data-marquee")
var akxhK=DcOjp.size_cont;
var SKeoB=0;
var SIjHw=0;
if(DcOjp.orientation!=0) 
{
SKeoB=-now;
}
else
{
SIjHw=-now;
}
var ZHOUa=akxhK.width()
var fWgAT=akxhK.height()
var DaMut=0;
var hbfRq=DaMut+SKeoB;
var XuBVZ=DaMut+SIjHw;
var vWEHN=ZHOUa+SKeoB;;
var TJStU=fWgAT+SIjHw
korDG.css("clip","rect("+XuBVZ+"px,"+vWEHN+"px,"+TJStU+"px,"+hbfRq+"px)")
}
}
function jXMWo(korDG,RLQFP)
{
var DcOjp=korDG.data("data-marquee")
var edNGr=DcOjp.prop
var IGBqu=DcOjp.size
var MdnKH=DcOjp.innerSize
var WnPQQ=DcOjp.compSize
var qOfUS=0;
var TFKNn=0;
var MbMRi={}
if(DcOjp.orientation!=0) 
{
if(RLQFP==false)
{
qOfUS=korDG.position().left;;
korDG.css({"left":qOfUS})
}
else
{
var tPWaZ=korDG.data("first-pos-marquee")
if(tPWaZ==undefined)
{
tPWaZ=korDG.position().left;
korDG.data("first-pos-marquee",tPWaZ)
}
else
{
korDG.css({"left":tPWaZ})
}
qOfUS=tPWaZ;
}
if(qOfUS<=-MdnKH)
{
qOfUS=WnPQQ
korDG.css(edNGr,qOfUS)
}
TFKNn=-IGBqu;
MbMRi={"left":TFKNn}
}
else
{
if(RLQFP==false)
{
qOfUS=korDG.position().top;;
korDG.css({"top":qOfUS})
}
else
{
var tPWaZ=korDG.data("first-pos-marquee")
if(tPWaZ==undefined)
{
tPWaZ=korDG.position().top;
korDG.data("first-pos-marquee",tPWaZ)
}
else
{
korDG.css({"top":tPWaZ})
}
qOfUS=tPWaZ;
}
if(qOfUS<=-MdnKH)
{
qOfUS=WnPQQ
korDG.css(edNGr,qOfUS)
}
TFKNn=-IGBqu;
MbMRi={"top":TFKNn}
}
var ganPu=((qOfUS-TFKNn)*1000)/DcOjp.speed
var SZmdo={
"duration":ganPu,"easing":"linear","complete":function(){jXMWo(waJSQuery(this),true);},"step":function(now,fx){xeQFO(waJSQuery(this),now,fx);}
};
korDG.animate(MbMRi,SZmdo);
}
function AkOoO(kpvpM)
{
var SFStB=parseInt(extractParamInfo(kpvpM,"orientation","param_marquee"))
var wUVlb=parseInt(extractParamInfo(kpvpM,"speed","param_marquee")) 

var korDG=kpvpM.find("div")
var edNGr="top"
var rRbrh=korDG.height()
var kNCwf=korDG.innerHeight()
var WnPQQ=kpvpM.height();
if(SFStB!=0) 
{
var RXftX=korDG.find("div")
var EMINR=RXftX.html()
var xspbH=korDG.innerWidth();
var fWgAT=RXftX.innerHeight();
var uEdAx=fWgAT
var BhEWV=xspbH;
for(var ZHOUa=xspbH;ZHOUa<10000;ZHOUa+=30)
{
korDG.css("width",ZHOUa)
fWgAT=RXftX.innerHeight();
if(fWgAT<uEdAx)
{
uEdAx=fWgAT
BhEWV=ZHOUa
}
}
korDG.css("width",BhEWV+2)
}
if(SFStB!=0) 
{
WnPQQ=kpvpM.width();
edNGr="left"
rRbrh=korDG.width()
kNCwf=korDG.innerWidth() 
korDG.css(edNGr,WnPQQ) 

}
else
{
WnPQQ=kpvpM.height();
edNGr="top"
rRbrh=korDG.height()
kNCwf=korDG.innerHeight()
korDG.css(edNGr,WnPQQ)
}
korDG.data("data-marquee",{"speed":wUVlb,"orientation":SFStB,"size":rRbrh,"innerSize":kNCwf,"prop":edNGr,"compSize":WnPQQ,"size_cont":new Size(kpvpM.width(),kpvpM.height())})
korDG.hover(function(){
waJSQuery(this).stop();
},function(){
jXMWo(waJSQuery(this),false)
});
jXMWo(korDG)
}
function initializeWA_JQuery()
{


if(isMSIE())
{
var xAVDb=new Array();
var CrEub=waWebFontDescription.families
for(var i=0;i<CrEub.length;i++)
{
var UKUiL=CrEub[i]
xAVDb.push(UKUiL+"::latin")
}
WebFontConfig={
google:{families:xAVDb}
};
if(xAVDb.length>0)
{
waLoadGoogleFonts()
}
}
IS_onload();




waJSQuery(".reflect").reflect();
waJSQuery(".wa-img").each(function()
{
var kpvpM=waJSQuery(this)
var OHkrp=extractParamInfo(kpvpM,"over");
if(OHkrp.length>0)
{
kpvpM.hover(function(){
var o=waJSQuery(this)
var img=o
var over=extractParamInfo(o,"over");
var EHiZn=waJSQuery(this).data('src_out') 
if(EHiZn==undefined)
{
waJSQuery(this).data('src_out',img.attr('src'))
}

img.attr("src",over)
},function(){
var o=waJSQuery(this)
var img=o
img.attr("src",waJSQuery(this).data("src_out")) 

});
}
}) 


waJSQuery(".wa-text").each(function()
{
if(isMSIE())
{
var ZHOUa=waJSQuery(this).width()
var fWgAT=waJSQuery(this).height()
var gDxwW=waJSQuery(this).children("div") 
var HONNb=parseInt(gDxwW.css("marginTop"))
if(isNaN(HONNb))HONNb=0;
var sWLpR=parseInt(extractParamInfo(waJSQuery(this),"border","param")) 
var DaMut=sWLpR;
gDxwW.css("margin",(HONNb+DaMut)+"px")
}
}) 


waJSQuery(".wa-textmarquee").each(function()
{
AkOoO(waJSQuery(this))
}) 


waActivateOverButtons()
waHackGradient()
waHackButtons()
waGlobalPatchIE()
}
function waGlobalPatchIE()
{
if(isMSIE())
{
if(window.waPatchIE)
{
waPatchIE()
}
}
}(function(waJSQuery){
waJSQuery.fn.extend({
reflect:function(options){
var kpvpM=waJSQuery(this)
var _radius=waExtractRadiusFromCss(kpvpM) 
options=waJSQuery.extend({
height:1/3,opacity:0.5,borderRadius:_radius
},options);
return this.unreflect().each(function(){
var img=this;
if(/^img$/i.test(img.tagName)){
function doReflect(){
var imageWidth=img.width,imageHeight=img.height,reflection,reflectionHeight,wrapper,context,gradient;
reflectionHeight=Math.floor(imageHeight*options.height)
reflection=waJSQuery("<canvas />")[0];
if(reflection.getContext){
context=reflection.getContext("2d");
try{
waJSQuery(reflection).attr({width:imageWidth,height:imageHeight});
context.save();
context.translate(0,imageHeight-1);
context.scale(1,-1);
context.drawImage(img,0,0,imageWidth,imageHeight);
context.restore();
context.globalCompositeOperation="destination-out";
gradient=context.createLinearGradient(0,0,0,reflectionHeight);
gradient.addColorStop(0,"rgba(255, 255, 255, "+(1-options.opacity)+")");
gradient.addColorStop(1,"rgba(255, 255, 255, 1.0)");
context.fillStyle=gradient;
context.rect(0,0,imageWidth,imageHeight);
context.fill();
}catch(e){
return;
}
}else{
if(!waJSQuery.browser.msie) return;
reflection=waJSQuery("<img />").attr("src",img.src).css({
width:imageWidth,height:imageHeight,marginBottom:reflectionHeight-imageHeight,filter:"FlipV progid:DXImageTransform.Microsoft.Alpha(Opacity="+(options.opacity*100)+", FinishOpacity=0, Style=1, StartX=0, StartY=0, FinishX=0, FinishY="+(reflectionHeight/imageHeight*100)+")"
})[0];
}
var nIDjq=options.borderRadius 
var jVpOi=new Array(nIDjq[3],nIDjq[2],nIDjq[1],nIDjq[0])
var eLxoZ=nIDjq.join("px ")+"px"
var vvDsf=jVpOi.join("px ")+"px"
waJSQuery(reflection).css({display:"block",borderRadius:vvDsf});
wrapper=waJSQuery(/^a$/i.test(img.parentNode.tagName)?"<span />":"<div />").insertAfter(img).append([img,reflection])[0];
wrapper.className=img.className;
waJSQuery.data(img,"reflected",wrapper.style.cssText=img.style.cssText);
waJSQuery(wrapper).css({width:imageWidth,height:imageHeight+reflectionHeight,overflow:"hidden"});
img.style.cssText="display: block;border:0px none;-webkit-border-radius:"+eLxoZ+";-moz-border-radius:"+eLxoZ+";border-radius:"+eLxoZ+";width:"+imageWidth+"px;height:"+imageHeight+"px;" 

img.className="reflected";
}
if(img.complete) doReflect();
else waJSQuery(img).load(doReflect);
}
});
},unreflect:function(){
return this.unbind("load").each(function(){
var img=this,reflected=waJSQuery.data(this,"reflected"),wrapper;
if(reflected!==undefined){
wrapper=img.parentNode;
img.className=wrapper.className;
img.style.cssText=reflected;
waJSQuery.removeData(img,"reflected");
wrapper.parentNode.replaceChild(img,wrapper);
}
});
}
});
})(waJSQuery);(function(waJSQuery){
waJSQuery.fn.touchwipe=function(settings){
var config={
min_move_x:20,min_move_y:20,wipeLeft:function(){},wipeRight:function(){},wipeUp:function(){},wipeDown:function(){},preventDefaultEvents:true
};
if(settings) waJSQuery.extend(config,settings);
this.each(function(){
var startX;
var startY;
var isMoving=false;
function cancelTouch(){
this.removeEventListener('touchmove',onTouchMove);
startX=null;
isMoving=false;
}
function onTouchMove(e){
if(config.preventDefaultEvents){
e.preventDefault();
}
if(isMoving){
var x=e.touches[0].pageX;
var y=e.touches[0].pageY;
var dx=startX-x;
var dy=startY-y;
if(Math.abs(dx)>=config.min_move_x){
cancelTouch();
if(dx>0){
config.wipeLeft();
}
else{
config.wipeRight();
}
}
else if(Math.abs(dy)>=config.min_move_y){
cancelTouch();
if(dy>0){
config.wipeDown();
}
else{
config.wipeUp();
}
}
}
}
function onTouchStart(e)
{
if(e.touches.length==1){
startX=e.touches[0].pageX;
startY=e.touches[0].pageY;
isMoving=true;
this.addEventListener('touchmove',onTouchMove,false);
}
}
if('ontouchstart' in document.documentElement){
this.addEventListener('touchstart',onTouchStart,false);
}
});
return this;
};
})(waJSQuery);



function waChgtLanguage(WWUes,MBhmv)
{
var PCkJX=Translator.m_languages;
var dVuGe=window.location.pathname;
var vavga=window.location.href;
var olGlo=window.location.host
var ivUmM=dVuGe.lastIndexOf("/")
var mRiKV=""
var TKOxQ=dVuGe
if(ivUmM>-1)
{
mRiKV=dVuGe.substring(0,ivUmM+1)
TKOxQ=dVuGe.substring(ivUmM+1)
}
if(TKOxQ.length==0)
{
TKOxQ="index.html"
vavga+=TKOxQ;
}
if(document.webaca_is_preview)
{
if(PCkJX!=undefined)
{
var bgdoI=PCkJX[WWUes]
if(bgdoI)
{
window.location.replace(bgdoI)
return;
}
}
}
else
{
var ZcpGB=vavga
ZcpGB=ZcpGB.replace(olGlo,MBhmv);
if(PCkJX!=undefined)
{
var bgdoI=PCkJX[WWUes]
ZcpGB=ZcpGB.replace(TKOxQ,bgdoI);

window.location.replace(ZcpGB)
}
}
}
function waAutoDetectAndRedirectLang(fBNOj)
{
if((fBNOj.enable_preview_redirect!=true)&&document.webaca_is_preview)
{
return;
}
if(isProbablyRobot())
{
return;
}
if((fBNOj.restricted_host!=undefined)&&(document.webaca_is_preview!=true))
{
var KFNdN=false;
for(var i=0;i<fBNOj.restricted_host.length;i++)
{
var MBhmv=fBNOj.restricted_host[i]
if(window.location.host==MBhmv)
{
KFNdN=true;
break;
}
}
if(KFNdN==false)
{
return;
}
}
var EiUiU=navigator.language;
if(navigator.browserLanguage)
EiUiU=navigator.browserLanguage;
var ivUmM=EiUiU.indexOf("-")
if(ivUmM>0)
{
EiUiU=EiUiU.substr(0,ivUmM)
}
if(Translator.m_lang!=EiUiU)
{
if(fBNOj.enabled_internal_redirect!=false)
{
var PCkJX=Translator.m_languages;
if(PCkJX)
{
var WWUes=PCkJX[EiUiU]
if(WWUes)
{
window.location.replace(WWUes)
return;
}
}
}
if(fBNOj.redirect!=undefined)
{
var MBhmv=fBNOj.redirect[EiUiU]
if(MBhmv!=undefined)
{
waChgtLanguage(EiUiU,MBhmv);

}
}
}
}

-->
