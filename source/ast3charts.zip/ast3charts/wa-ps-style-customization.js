var customFancyBox = new Array();
customFancyBox[ 'overlay' ] = 'rgba( 0, 0, 0, 0.5 )';